/* generated vector source file - do not edit */
#include "bsp_api.h"
/* Do not build these data structures if no interrupts are currently allocated because IAR will have build errors. */
#if VECTOR_DATA_IRQ_COUNT > 0
        BSP_DONT_REMOVE const fsp_vector_t g_vector_table[BSP_ICU_VECTOR_MAX_ENTRIES] BSP_PLACE_IN_SECTION(BSP_SECTION_APPLICATION_VECTORS) =
        {
                        [0] = r_icu_isr, /* ICU IRQ8 (External pin interrupt 8) */
            [1] = sci_uart_rxi_isr, /* SCI6 RXI (Received data full) */
            [2] = sci_uart_txi_isr, /* SCI6 TXI (Transmit data empty) */
            [3] = sci_uart_tei_isr, /* SCI6 TEI (Transmit end) */
            [4] = sci_uart_eri_isr, /* SCI6 ERI (Receive error) */
            [5] = sci_uart_rxi_isr, /* SCI9 RXI (Received data full) */
            [6] = sci_uart_txi_isr, /* SCI9 TXI (Transmit data empty) */
            [7] = sci_uart_tei_isr, /* SCI9 TEI (Transmit end) */
            [8] = sci_uart_eri_isr, /* SCI9 ERI (Receive error) */
            [9] = adc_scan_end_isr, /* ADC0 SCAN END (A/D scan end interrupt) */
            [10] = dmac_int_isr, /* DMAC0 INT (DMAC transfer end 0) */
            [11] = iic_master_rxi_isr, /* IIC0 RXI (Receive data full) */
            [12] = iic_master_txi_isr, /* IIC0 TXI (Transmit data empty) */
            [13] = iic_master_tei_isr, /* IIC0 TEI (Transmit end) */
            [14] = iic_master_eri_isr, /* IIC0 ERI (Transfer error) */
            [15] = iic_master_rxi_isr, /* IIC2 RXI (Receive data full) */
            [16] = iic_master_txi_isr, /* IIC2 TXI (Transmit data empty) */
            [17] = iic_master_tei_isr, /* IIC2 TEI (Transmit end) */
            [18] = iic_master_eri_isr, /* IIC2 ERI (Transfer error) */
            [19] = sci_uart_rxi_isr, /* SCI0 RXI (Receive data full) */
            [20] = sci_uart_txi_isr, /* SCI0 TXI (Transmit data empty) */
            [21] = sci_uart_tei_isr, /* SCI0 TEI (Transmit end) */
            [22] = sci_uart_eri_isr, /* SCI0 ERI (Receive error) */
        };
        const bsp_interrupt_event_t g_interrupt_event_link_select[BSP_ICU_VECTOR_MAX_ENTRIES] =
        {
            [0] = BSP_PRV_IELS_ENUM(EVENT_ICU_IRQ8), /* ICU IRQ8 (External pin interrupt 8) */
            [1] = BSP_PRV_IELS_ENUM(EVENT_SCI6_RXI), /* SCI6 RXI (Received data full) */
            [2] = BSP_PRV_IELS_ENUM(EVENT_SCI6_TXI), /* SCI6 TXI (Transmit data empty) */
            [3] = BSP_PRV_IELS_ENUM(EVENT_SCI6_TEI), /* SCI6 TEI (Transmit end) */
            [4] = BSP_PRV_IELS_ENUM(EVENT_SCI6_ERI), /* SCI6 ERI (Receive error) */
            [5] = BSP_PRV_IELS_ENUM(EVENT_SCI9_RXI), /* SCI9 RXI (Received data full) */
            [6] = BSP_PRV_IELS_ENUM(EVENT_SCI9_TXI), /* SCI9 TXI (Transmit data empty) */
            [7] = BSP_PRV_IELS_ENUM(EVENT_SCI9_TEI), /* SCI9 TEI (Transmit end) */
            [8] = BSP_PRV_IELS_ENUM(EVENT_SCI9_ERI), /* SCI9 ERI (Receive error) */
            [9] = BSP_PRV_IELS_ENUM(EVENT_ADC0_SCAN_END), /* ADC0 SCAN END (A/D scan end interrupt) */
            [10] = BSP_PRV_IELS_ENUM(EVENT_DMAC0_INT), /* DMAC0 INT (DMAC transfer end 0) */
            [11] = BSP_PRV_IELS_ENUM(EVENT_IIC0_RXI), /* IIC0 RXI (Receive data full) */
            [12] = BSP_PRV_IELS_ENUM(EVENT_IIC0_TXI), /* IIC0 TXI (Transmit data empty) */
            [13] = BSP_PRV_IELS_ENUM(EVENT_IIC0_TEI), /* IIC0 TEI (Transmit end) */
            [14] = BSP_PRV_IELS_ENUM(EVENT_IIC0_ERI), /* IIC0 ERI (Transfer error) */
            [15] = BSP_PRV_IELS_ENUM(EVENT_IIC2_RXI), /* IIC2 RXI (Receive data full) */
            [16] = BSP_PRV_IELS_ENUM(EVENT_IIC2_TXI), /* IIC2 TXI (Transmit data empty) */
            [17] = BSP_PRV_IELS_ENUM(EVENT_IIC2_TEI), /* IIC2 TEI (Transmit end) */
            [18] = BSP_PRV_IELS_ENUM(EVENT_IIC2_ERI), /* IIC2 ERI (Transfer error) */
            [19] = BSP_PRV_IELS_ENUM(EVENT_SCI0_RXI), /* SCI0 RXI (Receive data full) */
            [20] = BSP_PRV_IELS_ENUM(EVENT_SCI0_TXI), /* SCI0 TXI (Transmit data empty) */
            [21] = BSP_PRV_IELS_ENUM(EVENT_SCI0_TEI), /* SCI0 TEI (Transmit end) */
            [22] = BSP_PRV_IELS_ENUM(EVENT_SCI0_ERI), /* SCI0 ERI (Receive error) */
        };
        #endif
