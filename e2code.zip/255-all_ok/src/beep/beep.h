/*
 * beep.h
 *
 *  Created on: 2025年6月28日
 *      Author: 江
 */

#ifndef BEEP_BEEP_H_
#define BEEP_BEEP_H_
#include "hal_data.h"


void beep_init ();

void beep_on ();

void beep_off ();

#endif /* BEEP_BEEP_H_ */
