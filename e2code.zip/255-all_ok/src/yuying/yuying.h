/*
 * yuying.h
 *
 *  Created on: 2025年7月4日
 *      Author: 江
 */

#ifndef YUYING_YUYING_H_
#define YUYING_YUYING_H_

#include "hal_data.h"
#include "beep/beep.h"
#include "led/led.h"
void yuying_init ();
void yuying ();

#endif /* YUYING_YUYING_H_ */
