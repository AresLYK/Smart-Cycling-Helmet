/*
 * yuying.c
 *
 *  Created on: 2025年7月4日
 *      Author: 江
 */



#include "yuying.h"

void yuying_init ()
{

    R_IOPORT_Open(&g_ioport_ctrl, g_ioport.p_cfg);


}

void yuying ()
{
    bsp_io_level_t pin_state=BSP_IO_LEVEL_LOW;
        R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_02_PIN_09, &pin_state);

        // 添加串口调试输出
        printf("Sensor State: %s\r\n",
               (pin_state == BSP_IO_LEVEL_HIGH) ? "HIGH" : "LOW");

        if(pin_state == BSP_IO_LEVEL_HIGH) {
            led_on();
            //led_off();
        } else {
            led_off();
            //led_on();
        }
        R_BSP_SoftwareDelay(200, BSP_DELAY_UNITS_MILLISECONDS);
}
