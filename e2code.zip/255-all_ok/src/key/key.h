/*
 * key.h

 *
 *  Created on: 2025年5月25日
 *      Author: 江
 */

#ifndef KEY_KEY_H_
#define KEY_KEY_H_
#include "hal_data.h"
#define key_f1_pin  BSP_IO_PORT_00_PIN_01
//#define key_f2_pin  BSP_IO_PORT_00_PIN_02

#define key_on 1
#define key_off 0


void key_init ();
uint32_t key_scan (bsp_io_port_t key);

#endif /* KEY_KEY_H_ */
