/*
 * key.c
 *
 *  Created on: 2025年5月25日
 *      Author: 江
 */
#include "key.h"

void key_init ()
{
     R_IOPORT_Open(&g_ioport_ctrl, g_ioport.p_cfg);
}
//按键扫描函数
uint32_t key_scan (bsp_io_port_t key)
{

    bsp_io_level_t state;

    R_IOPORT_PinRead(&g_ioport_ctrl, key, &state);
    if( BSP_IO_LEVEL_HIGH==state)
    {
        return key_off;//按键没按下
    }
    else
    {
        do
        {
            R_IOPORT_PinRead(&g_ioport_ctrl, key, &state);

        }while(BSP_IO_LEVEL_LOW==state);
    }
    return key_on;//按键按下
}


