/*
 * hexstr.h
 *
 *  Created on: 2025年6月7日
 *      Author: 江
 */

#ifndef HEXSTR_HEXSTR_H_
#define HEXSTR_HEXSTR_H_
#include "hal_data.h"
#include "string.h"


extern char Value2Hex(const int value);
extern int Str2Hex(char *str,char *hex);

#endif /* HEXSTR_HEXSTR_H_ */
