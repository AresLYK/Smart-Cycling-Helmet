/*
 * systick.h
 *
 *  Created on: 2025年5月26日
 *      Author: 江
 */

#ifndef SYSTICK_SYSTICK_H_
#define SYSTICK_SYSTICK_H_
#include "hal_data.h"

typedef enum
{
    SYS_DELAY_UNITS_SECONDS = 200000000, //< Requested delay amount␣,→is in seconds
    SYS_DELAY_UNITS_MILLISECONDS = 200000, //< Requested delay amount␣,→is in milliseconds
    SYS_DELAY_UNITS_MICROSECONDS = 200 //< Requested delay amount␣,→is in microseconds
}sys_delay_units_t;

void systick_init (uint32_t IT_frequency );
void systick_delay (uint32_t delay,sys_delay_units_t uint);
void SysTick_Handler(void);
#endif /* SYSTICK_SYSTICK_H_ */
