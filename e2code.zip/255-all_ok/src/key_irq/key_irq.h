/*
 * key_irq.h
 *
 *  Created on: 2025年5月26日
 *      Author: 江
 */

#ifndef KEY_IRQ_KEY_IRQ_H_
#define KEY_IRQ_KEY_IRQ_H_

#include "hal_data.h"


//按键引脚定义
#define key_f2_pin  BSP_IO_PORT_00_PIN_02
void key_irq_init ();


#endif /* KEY_IRQ_KEY_IRQ_H_ */
