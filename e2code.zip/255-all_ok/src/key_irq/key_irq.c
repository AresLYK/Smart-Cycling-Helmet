/*
 * key_irq.c
 *
 *  Created on: 2025年5月26日
 *      Author: 江
 */
#include "key_irq.h"


void key_irq_init ()
{
    fsp_err_t err =FSP_SUCCESS;
    err = R_ICU_ExternalIrqOpen(&g_external_irq8_ctrl, &g_external_irq8_cfg);

    err = R_ICU_ExternalIrqEnable(&g_external_irq8_ctrl);
     assert(FSP_SUCCESS==err);

}

volatile bool key_f2_press =false;
void key_extermal_irq_callback (external_irq_callback_args_t *p_args)
{
   if(8==p_args->channel)
   {
       key_f2_press=true;//按键按下
   }




}
