/*
 * sc505.c
 *
 *  Created on: 2025年6月28日
 *      Author: 江
 */

#include "sc505.h"
#include "led/led.h"


void sc505_init ()
{

    R_IOPORT_Open(&g_ioport_ctrl, g_ioport.p_cfg);


}

void sc505 ()
{
    bsp_io_level_t pin_state=BSP_IO_LEVEL_LOW;
        R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_05, &pin_state);

        // 添加串口调试输出
        printf("Sensor State: %s\r\n",
               (pin_state == BSP_IO_LEVEL_HIGH) ? "HIGH" : "LOW");

        if(pin_state == BSP_IO_LEVEL_HIGH) {
            beep_on ();;
            //led_off();
        } else {
            beep_off ();
            //led_on();
        }
        R_BSP_SoftwareDelay(200, BSP_DELAY_UNITS_MILLISECONDS);
}





