//#include "mpu6050.h"
//#include "hal_data.h"
//#include <stdio.h>
//#include <math.h>  // 添加数学函数支持
//
//// MPU6050寄存器定义
//#define MPU6050_ADDR             0x68
//#define MPU6050_RA_WHO_AM_I       0x75
//#define MPU6050_RA_PWR_MGMT_1     0x6B
//#define MPU6050_RA_SMPLRT_DIV     0x19
//#define MPU6050_RA_CONFIG         0x1A
//#define MPU6050_RA_ACCEL_CONFIG   0x1C
//#define MPU6050_RA_GYRO_CONFIG    0x1B
//#define MPU6050_RA_ACCEL_OUT      0x3B
//#define MPU6050_RA_TEMP_OUT_H     0x41
//#define MPU6050_RA_GYRO_OUT       0x43
//
//// 全局变量
//static volatile i2c_master_event_t g_i2c_callback_event;
//static volatile uint32_t g_i2c_timeout = 1000;
//static uint8_t g_i2c_initialized = 0;
//
//// I2C回调函数
//void iic_callback(i2c_master_callback_args_t *p_args)
//{
//    g_i2c_callback_event = p_args->event;
//}
//
//// I2C初始化
//fsp_err_t iic_init(void)
//{
//    if (g_i2c_initialized) return FSP_SUCCESS;
//
//    fsp_err_t err = R_IIC_MASTER_Open(&g_i2c_master0_ctrl, &g_i2c_master0_cfg);
//    if (FSP_SUCCESS != err) {
//        printf("I2C Open Error: 0x%x\n", err);
//        return err;
//    }
//
//    // 设置从机地址
//    R_IIC_MASTER_SlaveAddressSet(&g_i2c_master0_ctrl, MPU6050_ADDR, I2C_MASTER_ADDR_MODE_7BIT);
//
//    R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MILLISECONDS);
//    g_i2c_initialized = 1;
//
//    printf("I2C Initialized Successfully\n");
//    return FSP_SUCCESS;
//}
//
//// 等待I2C事件
//static uint8_t wait_for_i2c_event(i2c_master_event_t expected_event)
//{
//    uint32_t timeout = g_i2c_timeout;
//    g_i2c_callback_event = I2C_MASTER_EVENT_ABORTED;
//
//    while ((g_i2c_callback_event != expected_event) && timeout) {
//        R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_MILLISECONDS);
//        timeout--;
//    }
//
//    if (timeout == 0) {
//        printf("I2C Timeout! Expected: %d, Actual: %d\n",
//              expected_event, g_i2c_callback_event);
//        return 0;
//    }
//    return 1;
//}
//
//// I2C写函数
//uint8_t I2C_ByteWrite(uint8_t reg, uint8_t data)
//{
//    uint8_t send_buffer[2] = {reg, data};
//
//    // 启动写操作
//    fsp_err_t err = R_IIC_MASTER_Write(&g_i2c_master0_ctrl, send_buffer, 2, false);
//    if (FSP_SUCCESS != err) {
//        printf("I2C Write Start Error: 0x%x\n", err);
//        return 0;
//    }
//
//    // 等待传输完成
//    if (!wait_for_i2c_event(I2C_MASTER_EVENT_TX_COMPLETE)) {
//        return 0;
//    }
//
//    return 1;
//}
//
//// I2C读函数
//uint8_t I2C_BufferRead(uint8_t reg, uint8_t *buffer, uint16_t size)
//{
//    // 发送寄存器地址
//    fsp_err_t err = R_IIC_MASTER_Write(&g_i2c_master0_ctrl, &reg, 1, true);
//    if (FSP_SUCCESS != err) {
//        printf("I2C Register Address Error: 0x%x\n", err);
//        return 0;
//    }
//
//    // 等待地址发送完成
//    if (!wait_for_i2c_event(I2C_MASTER_EVENT_TX_COMPLETE)) {
//        return 0;
//    }
//
//    // 启动读操作
//    err = R_IIC_MASTER_Read(&g_i2c_master0_ctrl, buffer, size, false);
//    if (FSP_SUCCESS != err) {
//        printf("I2C Read Start Error: 0x%x\n", err);
//        return 0;
//    }
//
//    // 等待读取完成
//    if (!wait_for_i2c_event(I2C_MASTER_EVENT_RX_COMPLETE)) {
//        return 0;
//    }
//
//    return 1;
//}
//
//// MPU6050初始化
//uint8_t MPU6050_Init(void)
//{
//    // 确保I2C已初始化
//    if (iic_init() != FSP_SUCCESS) {
//        printf("I2C Init Failed\n");
//        return 0;
//    }
//
//    printf("Initializing MPU6050...\n");
//
//    // 1. 唤醒设备
//    if (!I2C_ByteWrite(MPU6050_RA_PWR_MGMT_1, 0x00)) {
//        printf("Wakeup Command Failed\n");
//        return 0;
//    }
//    R_BSP_SoftwareDelay(100, BSP_DELAY_UNITS_MILLISECONDS);
//
//    // 2. 检查设备ID
//    uint8_t device_id = 0;
//    if (!I2C_BufferRead(MPU6050_RA_WHO_AM_I, &device_id, 1)) {
//        printf("ID Read Failed\n");
//        return 0;
//    }
//
//    if (device_id != 0x68) {
//        printf("Invalid MPU6050 ID: 0x%02X (expected 0x68)\n", device_id);
//        return 0;
//    }
//    printf("MPU6050 ID Verified: 0x%02X\n", device_id);
//
//    // 3. 配置设备
//    uint8_t success = 1;
//
//    // 设置采样率 (1kHz)
//    success &= I2C_ByteWrite(MPU6050_RA_SMPLRT_DIV, 0x07);
//
//    // 设置低通滤波器 (5Hz)
//    success &= I2C_ByteWrite(MPU6050_RA_CONFIG, 0x06);
//
//    // 设置加速度计量程 (±2g)
//    success &= I2C_ByteWrite(MPU6050_RA_ACCEL_CONFIG, 0x00);
//
//    // 设置陀螺仪量程 (±2000dps)
//    success &= I2C_ByteWrite(MPU6050_RA_GYRO_CONFIG, 0x18);
//
//    // 设置时钟源 (PLL with X axis gyro)
//    success &= I2C_ByteWrite(MPU6050_RA_PWR_MGMT_1, 0x01);
//
//    R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MILLISECONDS);
//
//    if (!success) {
//        printf("MPU6050 Configuration Failed\n");
//        return 0;
//    }
//
//    printf("MPU6050 Initialized Successfully\n");
//    return 1;
//}
//
//// 读取原始加速度数据
//uint8_t MPU6050_ReadRawAcc(int16_t *accData)
//{
//    uint8_t buf[6];
//    if (!I2C_BufferRead(MPU6050_RA_ACCEL_OUT, buf, 6)) {
//        return 0;
//    }
//
//    // 组合16位数据 (高位在前)
//    accData[0] = (int16_t)((buf[0] << 8) | buf[1]);
//    accData[1] = (int16_t)((buf[2] << 8) | buf[3]);
//    accData[2] = (int16_t)((buf[4] << 8) | buf[5]);
//
//    return 1;
//}
//
//// 读取加速度数据（单位：g）
//uint8_t MPU6050_ReadAcc(float *accData)
//{
//    int16_t raw[3];
//    if (!MPU6050_ReadRawAcc(raw)) {
//        return 0;
//    }
//
//    // ±2g量程，灵敏度16384 LSB/g
//    const float scale = 16384.0f;
//    accData[0] = (float)raw[0] / scale;
//    accData[1] = (float)raw[1] / scale;
//    accData[2] = (float)raw[2] / scale;
//
//    return 1;
//}
//
//// 读取原始陀螺仪数据
//uint8_t MPU6050_ReadRawGyro(int16_t *gyroData)
//{
//    uint8_t buf[6];
//    if (!I2C_BufferRead(MPU6050_RA_GYRO_OUT, buf, 6)) {
//        return 0;
//    }
//
//    // 组合16位数据 (高位在前)
//    gyroData[0] = (int16_t)((buf[0] << 8) | buf[1]);
//    gyroData[1] = (int16_t)((buf[2] << 8) | buf[3]);
//    gyroData[2] = (int16_t)((buf[4] << 8) | buf[5]);
//
//    return 1;
//}
//
//// 读取陀螺仪数据（单位：dps）
//uint8_t MPU6050_ReadGyro(float *gyroData)
//{
//    int16_t raw[3];
//    if (!MPU6050_ReadRawGyro(raw)) {
//        return 0;
//    }
//
//    // ±2000dps量程，灵敏度16.4 LSB/dps
//    const float scale = 16.4f;
//    gyroData[0] = (float)raw[0] / scale;
//    gyroData[1] = (float)raw[1] / scale;
//    gyroData[2] = (float)raw[2] / scale;
//
//    return 1;
//}
//
//// 读取温度数据（单位：°C）
//uint8_t MPU6050_ReadTemp(float *temperature)
//{
//    uint8_t buf[2];
//    if (!I2C_BufferRead(MPU6050_RA_TEMP_OUT_H, buf, 2)) {
//        return 0;
//    }
//
//    // 组合16位温度值
//    int16_t raw_temp = (int16_t)((buf[0] << 8) | buf[1]);
//
//    // 转换公式：TEMP_degC = (TEMP_OUT / 340) + 36.53
//    *temperature = (float)raw_temp / 340.0f + 36.53f;
//
//    return 1;
//}
//
//// 主函数
//void mpu6050_main(void)
//{
//    printf("\n===== MPU6050 Data Reader =====\n");
//
//    // 初始化I2C
//    if (iic_init() != FSP_SUCCESS) {
//        printf("I2C Initialization Failed!\n");
//        while(1);
//    }
//
//    // 初始化MPU6050
//    if (!MPU6050_Init()) {
//        printf("MPU6050 Initialization Failed!\n");
//        while(1);
//    }
//
//    printf("MPU6050 Initialized Successfully!\n");
//
//    // 数据缓冲区
//    float accel[3], gyro[3], temperature;
//
//    // 检查printf浮点支持
//    float test_float = 1.2345f;
//    printf("Float Test: %f (should be 1.2345)\n", test_float);
//
//    while(1) {
//        uint8_t success = 1;
//
//        // 读取原始数据
//        int16_t raw_acc[3], raw_gyro[3];
//        success &= MPU6050_ReadRawAcc(raw_acc);
//        success &= MPU6050_ReadRawGyro(raw_gyro);
//
//        // 读取并显示处理后的数据
//        success &= MPU6050_ReadAcc(accel);
//        success &= MPU6050_ReadGyro(gyro);
//        success &= MPU6050_ReadTemp(&temperature);
//
//        if (success) {
//            // 方法1：直接打印浮点数
//            printf("Accel: X=%7.3fg, Y=%7.3fg, Z=%7.3fg | ",
//                   accel[0], accel[1], accel[2]);
//            printf("Gyro: X=%8.2fdps, Y=%8.2fdps, Z=%8.2fdps | ",
//                   gyro[0], gyro[1], gyro[2]);
//            printf("Temp: %6.2f°C\n", temperature);
//
//            // 方法2：整数打印（备选方案）
//            printf("Alt: AccX=%dmg, AccY=%dmg, AccZ=%dmg | ",
//                   (int)(accel[0] * 1000), (int)(accel[1] * 1000), (int)(accel[2] * 1000));
//            printf("GyroX=%dmdps, GyroY=%dmdps, GyroZ=%dmdps | ",
//                   (int)(gyro[0] * 1000), (int)(gyro[1] * 1000), (int)(gyro[2] * 1000));
//            printf("Temp=%dC\n", (int)(temperature * 100));
//
//            // 方法3：原始数据打印
//            printf("Raw: AccX=%6d, AccY=%6d, AccZ=%6d | ",
//                   raw_acc[0], raw_acc[1], raw_acc[2]);
//            printf("GyroX=%6d, GyroY=%6d, GyroZ=%6d\n",
//                   raw_gyro[0], raw_gyro[1], raw_gyro[2]);
//        } else {
//            printf("Data Read Failed\n");
//        }
//
//        printf("------------------------------------------------\n");
//        R_BSP_SoftwareDelay(500, BSP_DELAY_UNITS_MILLISECONDS);
//    }
//}

#include "mpu6050.h"
#include "hal_data.h"
#include <stdio.h>
#include <stdlib.h>  // 添加整数转换支持

// MPU6050寄存器定义
#define MPU6050_ADDR             0x68
#define MPU6050_RA_WHO_AM_I       0x75
#define MPU6050_RA_PWR_MGMT_1     0x6B
#define MPU6050_RA_SMPLRT_DIV     0x19
#define MPU6050_RA_CONFIG         0x1A
#define MPU6050_RA_ACCEL_CONFIG   0x1C
#define MPU6050_RA_GYRO_CONFIG    0x1B
#define MPU6050_RA_ACCEL_OUT      0x3B
#define MPU6050_RA_TEMP_OUT_H     0x41
#define MPU6050_RA_GYRO_OUT       0x43




int32_t accel[3];

// 全局变量
static volatile i2c_master_event_t g_i2c_callback_event;
static volatile uint32_t g_i2c_timeout = 1000;
static uint8_t g_i2c_initialized = 0;

// I2C回调函数
void iic_callback(i2c_master_callback_args_t *p_args)
{
    g_i2c_callback_event = p_args->event;
}

// I2C初始化
fsp_err_t iic_init(void)
{
    if (g_i2c_initialized) return FSP_SUCCESS;

    fsp_err_t err = R_IIC_MASTER_Open(&g_i2c_master0_ctrl, &g_i2c_master0_cfg);
    if (FSP_SUCCESS != err) {
        printf("I2C Open Error: 0x%x\n", err);
        return err;
    }

    // 设置从机地址
    R_IIC_MASTER_SlaveAddressSet(&g_i2c_master0_ctrl, MPU6050_ADDR, I2C_MASTER_ADDR_MODE_7BIT);

    R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MILLISECONDS);
    g_i2c_initialized = 1;

    printf("I2C Initialized Successfully\n");
    return FSP_SUCCESS;
}

// 等待I2C事件
static uint8_t wait_for_i2c_event(i2c_master_event_t expected_event)
{
    uint32_t timeout = g_i2c_timeout;
    g_i2c_callback_event = I2C_MASTER_EVENT_ABORTED;

    while ((g_i2c_callback_event != expected_event) && timeout) {
        R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_MILLISECONDS);
        timeout--;
    }

    if (timeout == 0) {
        printf("I2C Timeout! Expected: %d, Actual: %d\n",
              expected_event, g_i2c_callback_event);
        return 0;
    }
    return 1;
}

// I2C写函数
uint8_t I2C_ByteWrite(uint8_t reg, uint8_t data)
{
    uint8_t send_buffer[2] = {reg, data};

    // 启动写操作
    fsp_err_t err = R_IIC_MASTER_Write(&g_i2c_master0_ctrl, send_buffer, 2, false);
    if (FSP_SUCCESS != err) {
        printf("I2C Write Start Error: 0x%x\n", err);
        return 0;
    }

    // 等待传输完成
    if (!wait_for_i2c_event(I2C_MASTER_EVENT_TX_COMPLETE)) {
        return 0;
    }

    return 1;
}

// I2C读函数
uint8_t I2C_BufferRead(uint8_t reg, uint8_t *buffer, uint16_t size)
{
    // 发送寄存器地址
    fsp_err_t err = R_IIC_MASTER_Write(&g_i2c_master0_ctrl, &reg, 1, true);
    if (FSP_SUCCESS != err) {
        printf("I2C Register Address Error: 0x%x\n", err);
        return 0;
    }

    // 等待地址发送完成
    if (!wait_for_i2c_event(I2C_MASTER_EVENT_TX_COMPLETE)) {
        return 0;
    }

    // 启动读操作
    err = R_IIC_MASTER_Read(&g_i2c_master0_ctrl, buffer, size, false);
    if (FSP_SUCCESS != err) {
        printf("I2C Read Start Error: 0x%x\n", err);
        return 0;
    }

    // 等待读取完成
    if (!wait_for_i2c_event(I2C_MASTER_EVENT_RX_COMPLETE)) {
        return 0;
    }

    return 1;
}

// MPU6050初始化
uint8_t MPU6050_Init(void)
{

    iic_init();
    // 确保I2C已初始化
    if (iic_init() != FSP_SUCCESS) {
        printf("I2C Init Failed\n");
        return 0;
    }

    printf("Initializing MPU6050...\n");

    // 1. 唤醒设备
    if (!I2C_ByteWrite(MPU6050_RA_PWR_MGMT_1, 0x00)) {
        printf("Wakeup Command Failed\n");
        return 0;
    }
    R_BSP_SoftwareDelay(100, BSP_DELAY_UNITS_MILLISECONDS);

    // 2. 检查设备ID
    uint8_t device_id = 0;
    if (!I2C_BufferRead(MPU6050_RA_WHO_AM_I, &device_id, 1)) {
        printf("ID Read Failed\n");
        return 0;
    }

    if (device_id != 0x68) {
        printf("Invalid MPU6050 ID: 0x%02X (expected 0x68)\n", device_id);
        return 0;
    }
    printf("MPU6050 ID Verified: 0x%02X\n", device_id);

    // 3. 配置设备
    uint8_t success = 1;

    // 设置采样率 (1kHz)
    success &= I2C_ByteWrite(MPU6050_RA_SMPLRT_DIV, 0x07);

    // 设置低通滤波器 (5Hz)
    success &= I2C_ByteWrite(MPU6050_RA_CONFIG, 0x06);

    // 设置加速度计量程 (±2g)
    success &= I2C_ByteWrite(MPU6050_RA_ACCEL_CONFIG, 0x00);

    // 设置陀螺仪量程 (±2000dps)
    success &= I2C_ByteWrite(MPU6050_RA_GYRO_CONFIG, 0x18);

    // 设置时钟源 (PLL with X axis gyro)
    success &= I2C_ByteWrite(MPU6050_RA_PWR_MGMT_1, 0x01);

    R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MILLISECONDS);

    if (!success) {
        printf("MPU6050 Configuration Failed\n");
        return 0;
    }

    printf("MPU6050 Initialized Successfully\n");
    return 1;
}

// 读取原始加速度数据
uint8_t MPU6050_ReadRawAcc(int16_t *accData)
{
    uint8_t buf[6];
    if (!I2C_BufferRead(MPU6050_RA_ACCEL_OUT, buf, 6)) {
        return 0;
    }

    // 组合16位数据 (高位在前)
    accData[0] = (int16_t)((buf[0] << 8) | buf[1]);
    accData[1] = (int16_t)((buf[2] << 8) | buf[3]);
    accData[2] = (int16_t)((buf[4] << 8) | buf[5]);

    return 1;
}

// 读取加速度数据（单位：g）并转换为整数
uint8_t MPU6050_ReadAcc(int32_t *accData)
{
    int16_t raw[3];
    if (!MPU6050_ReadRawAcc(raw)) {
        return 0;
    }

    // ±2g量程，灵敏度16384 LSB/g，转换为毫克(mg)
    const float scale = 16384.0f;
    accData[0] = (int32_t)((float)raw[0] * 1000 / scale);
    accData[1] = (int32_t)((float)raw[1] * 1000 / scale);
    accData[2] = (int32_t)((float)raw[2] * 1000 / scale);

    return 1;
}

// 读取原始陀螺仪数据
uint8_t MPU6050_ReadRawGyro(int16_t *gyroData)
{
    uint8_t buf[6];
    if (!I2C_BufferRead(MPU6050_RA_GYRO_OUT, buf, 6)) {
        return 0;
    }

    // 组合16位数据 (高位在前)
    gyroData[0] = (int16_t)((buf[0] << 8) | buf[1]);
    gyroData[1] = (int16_t)((buf[2] << 8) | buf[3]);
    gyroData[2] = (int16_t)((buf[4] << 8) | buf[5]);

    return 1;
}

// 读取陀螺仪数据（单位：dps）并转换为整数
uint8_t MPU6050_ReadGyro(int32_t *gyroData)
{
    int16_t raw[3];
    if (!MPU6050_ReadRawGyro(raw)) {
        return 0;
    }

    // ±2000dps量程，灵敏度16.4 LSB/dps，转换为毫度/秒(mdps)
    const float scale = 16.4f;
    gyroData[0] = (int32_t)((float)raw[0] * 1000 / scale);
    gyroData[1] = (int32_t)((float)raw[1] * 1000 / scale);
    gyroData[2] = (int32_t)((float)raw[2] * 1000 / scale);

    return 1;
}

// 读取温度数据（单位：°C）并转换为整数
uint8_t MPU6050_ReadTemp(int32_t *temperature)
{
    uint8_t buf[2];
    if (!I2C_BufferRead(MPU6050_RA_TEMP_OUT_H, buf, 2)) {
        return 0;
    }

    // 组合16位温度值
    int16_t raw_temp = (int16_t)((buf[0] << 8) | buf[1]);

    // 转换公式：TEMP_degC = (TEMP_OUT / 340) + 36.53
    float temp_float = (float)raw_temp / 340.0f + 36.53f;
    *temperature = (int32_t)(temp_float * 100);  // 转换为0.01°C单位

    return 1;
}

// 主函数
void mpu6050_main(void)
{
//    printf("\n===== MPU6050 Data Reader =====\n");
//
//    // 初始化I2C
//    if (iic_init() != FSP_SUCCESS) {
//        printf("I2C Initialization Failed!\n");
//        while(1);
//    }
//
//    // 初始化MPU6050
//    if (!MPU6050_Init()) {
//        printf("MPU6050 Initialization Failed!\n");
//        while(1);
//    }
//
//    printf("MPU6050 Initialized Successfully!\n");

    // 数据缓冲区
    int32_t gyro[3], temperature;
    int16_t raw_acc[3], raw_gyro[3];


        uint8_t success = 1;

        // 读取原始数据
        success &= MPU6050_ReadRawAcc(raw_acc);
        success &= MPU6050_ReadRawGyro(raw_gyro);

        // 读取处理后的数据（整数格式）
        success &= MPU6050_ReadAcc(accel);
        success &= MPU6050_ReadGyro(gyro);
        success &= MPU6050_ReadTemp(&temperature);

        // XX=accel[0]/1000;
        // printf("%d",XX);
        if (success) {
            // 打印处理后的数据（整数格式）
//            printf("Accel: X=%5d.%03dg\n",
//                   accel[0]/1000, abs(accel[0]%1000));
                   //accel[1]/1000, abs(accel[1]%1000),
                  // accel[2]/1000, abs(accel[2]%1000));



//            printf("Gyro: X=%5d.%03gdps, Y=%5d.%03gdps, Z=%5d.%03gdps | ",
//                   gyro[0]/1000, abs(gyro[0]%1000),
//                   gyro[1]/1000, abs(gyro[1]%1000),
//                   gyro[2]/1000, abs(gyro[2]%1000));
//
//            printf("Temp: %2d.%02dC\n",
//                   temperature/100, abs(temperature%100));
//
//            // 打印原始数据
//            printf("Raw: AccX=%6d, AccY=%6d, AccZ=%6d | ",
//                   raw_acc[0], raw_acc[1], raw_acc[2]);
//            printf("GyroX=%6d, GyroY=%6d, GyroZ=%6d\n",
//                   raw_gyro[0], raw_gyro[1], raw_gyro[2]);
        } else {
            printf("Data Read Failed\n");
        }

        //printf("------------------------------------------------\n");
        R_BSP_SoftwareDelay(500, BSP_DELAY_UNITS_MILLISECONDS);

}





