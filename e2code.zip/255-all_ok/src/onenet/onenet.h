/*
 * onenet.h
 *
 *  Created on: 2025年6月14日
 *      Author: 江
 */

#ifndef ONENET_ONENET_H_
#define ONENET_ONENET_H_
#include "hal_data.h"
#include "stdio.h"
#include "bc20/bc20.h"
#include <string.h>

void bc20_onenet ();
unsigned int MakeOnenetPayload(uint8_t *buffer, uint8_t temp, uint8_t humi);//将温度与湿度封装成Onenet有效载荷包
//void send_to_onenet(uint8_t temp, uint8_t humi);//上发数据
//void IWDT_Init(void);
//void IWDT_Feed(void);
//void bc20_SendData(uint8_t* data, uint16_t len);
//void iot_senddata(unsigned char temp, unsigned char humi);
//void bc20_SendData(uint8_t* data, uint16_t len);




void iot_send (int x ,int y);
int Get_GPSdata();
void ConvertAndPublish();
char *Get_GPS_RMC(char type);
void iot_sendGPS (char * x,char * y);
extern char latStrAF[128];
extern char lonStrAF[128];
void Getdata_Change(char status);


void iot_sendMAX30102 (int x ,int y);
void iot_sendmpu6050 (int X,int x, int Y,int y,int Z,int z);
#endif /* ONENET_ONENET_H_ */
