/*
 * ADC.c
 *
 *  Created on: 2025年6月7日
 *      Author: 江
 */
#include "ADC_DMA/ADC.h"
#include "stdio.h"

volatile bool adc_scan_complete = false;
volatile bool dma_complete_flag = false; // DMA传输完成标志
volatile uint16_t adc_data[16]; // 存储ADC转换结果



void set_transfer_dst_src_address( transfer_cfg_t const * const p_config,
                                        void const * volatile p_src,
                                        void const * volatile p_dest )
{
p_config->p_info->p_src = (void *) p_src;
p_config->p_info->p_dest = (void *)p_dest;
}


void const * p_src = &(R_ADC0->ADBUF0); // ADC缓冲区地址作为源地址
void const * p_dest = adc_data; // 目标地址



void ADC_init()
{
    fsp_err_t err;
    err = R_ADC_Open(&g_adc0_ctrl, &g_adc0_cfg); // 打开ADC模块
    assert(FSP_SUCCESS == err);

    err = R_ADC_ScanCfg(&g_adc0_ctrl, &g_adc0_channel_cfg); // 配置ADC扫描通道
    assert(FSP_SUCCESS == err);



    //R_ADC_ScanStart(&g_adc0_ctrl);
}



void DMA_init()
{


    set_transfer_dst_src_address(&dma0_cfg, p_src, p_dest);
    fsp_err_t err;

    err = R_DMAC_Open(&dma0_ctrl, &dma0_cfg); // 打开DMA模块
    assert(FSP_SUCCESS == err);



    R_DMAC_Enable(&dma0_ctrl); // 启用DMA
}

void adc0_callback(adc_callback_args_t *p_args)
{
    //FSP_PARAMETER_NOT_USED(p_args);
    adc_scan_complete  = true;
}

void dma0_callback(dmac_callback_args_t *p_args)
{
    FSP_PARAMETER_NOT_USED(p_args); // 避免未使用参数的警告
    dma_complete_flag = true; // 设置DMA传输完成标志
}

float Read_ADC_Value()
{
    uint16_t ADC_data;
    float a0;

    // 启动ADC扫描
    R_ADC_ScanStart(&g_adc0_ctrl);

    // 等待扫描完成
       while (!adc_scan_complete)
       {
           __NOP(); // 空操作减少功耗
       }
       adc_scan_complete = false; // 重置标志

       // 等待DMA传输完成
       while (!dma_complete_flag)
       {
           __NOP();
       }
       dma_complete_flag = false; // 重置标志

    // 读取DMA传输的结果
    ADC_data = adc_data;

    // 将ADC值转换为电压
    a0 = (float)(ADC_data * 3.3 / 4095);
    return a0;
}



