/*
 * ADC.h
 *
 *  Created on: 2025年6月7日
 *      Author: 江
 */

#ifndef ADC_DMA_ADC_H_
#define ADC_DMA_ADC_H_
#include "hal_data.h"

extern volatile bool adc_scan_complete;
extern volatile bool dma_complete_flag;


void ADC_init();
void DMA_init();


float  Read_ADC_Value();

#endif /* ADC_DMA_ADC_H_ */
