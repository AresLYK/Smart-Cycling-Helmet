/*
 * MAX30102.h
 *
 *  Created on: 2025年6月27日
 *      Author: 江
 */

#ifndef MAX30102_MAX30102_H_
#define MAX30102_MAX30102_H_
#include "hal_data.h"

void MAX30102_PrintData(void);

void MAX30102_Init(void);



 extern uint16_t avg_hr;
 extern uint16_t avg_spo2;
#endif /* MAX30102_MAX30102_H_ */
