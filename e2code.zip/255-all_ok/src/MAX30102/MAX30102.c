

#include "MAX30102.h"

#define MAX30102_ADDR 0x57  // 7位地址
#define I2C_WRITE_ADDR (MAX30102_ADDR << 1)
#define REG_INTR_STATUS_1 0x00
#define REG_INTR_STATUS_2 0x01
#define REG_INTR_ENABLE_1 0x02
#define REG_INTR_ENABLE_2 0x03
#define REG_FIFO_WR_PTR 0x04
#define REG_OVF_COUNTER 0x05
#define REG_FIFO_RD_PTR 0x06
#define REG_TEMP_CONFIG 0x21
#define REG_TEMP_INTR 0x1F
#define REG_TEMP_FRAC 0x20
#define REG_FIFO_DATA 0x07
#define REG_MODE_CONFIG 0x09
#define REG_FIFO_CONFIG 0x08
#define REG_SPO2_CONFIG 0x0A
#define REG_LED1_PA 0x0C
#define REG_LED2_PA 0x0D
#define REG_PILOT_PA 0x10






// I2C地址
#define I2C_WRITE_ADDR 0xAE
#define I2C_READ_ADDR  0xAF

// 寄存器地址
#define REG_INTR_STATUS_1     0x00
#define REG_INTR_STATUS_2     0x01
#define REG_INTR_ENABLE_1     0x02
#define REG_INTR_ENABLE_2     0x03
#define REG_FIFO_WR_PTR       0x04
#define REG_OVF_COUNTER       0x05
#define REG_FIFO_RD_PTR       0x06
#define REG_FIFO_DATA         0x07
#define REG_FIFO_CONFIG       0x08
#define REG_MODE_CONFIG       0x09
#define REG_SPO2_CONFIG       0x0A
#define REG_LED1_PA           0x0C
#define REG_LED2_PA           0x0D
#define REG_PILOT_PA          0x10
#define REG_MULTI_LED_CTRL1   0x11
#define REG_MULTI_LED_CTRL2   0x12
#define REG_TEMP_INTR         0x1F
#define REG_TEMP_FRAC         0x20
#define REG_TEMP_CONFIG       0x21
#define REG_PROX_INT_THRESH   0x30
#define REG_REV_ID            0xFE
#define REG_PART_ID           0xFF




uint16_t avg_hr;
uint16_t avg_spo2;

// 全局变量
static volatile i2c_master_event_t g_i2c1_callback_event;
static volatile uint32_t g_i2c1_timeout = 1000;
static uint8_t g_i2c1_initialized = 0;

// I2C回调函数
void iic1_callback(i2c_master_callback_args_t *p_args)
{
    g_i2c1_callback_event = p_args->event;
}





//void iic1_callback(i2c_master_callback_args_t *p_args)
//{
//    g_i2c1_callback_event = p_args->event;
//
//}


// I2C初始化
fsp_err_t iic1_init(void)
{
    if (g_i2c1_initialized) return FSP_SUCCESS;

    fsp_err_t err = R_IIC_MASTER_Open(&g_i2c_master1_ctrl, &g_i2c_master1_cfg);
    if (FSP_SUCCESS != err) {
        printf("I2C Open Error: 0x%x\n", err);
        return err;
    }

    // 设置从机地址
    R_IIC_MASTER_SlaveAddressSet(&g_i2c_master1_ctrl, MAX30102_ADDR, I2C_MASTER_ADDR_MODE_7BIT);

    // 注册回调函数
    err = R_IIC_MASTER_CallbackSet(&g_i2c_master1_ctrl, iic1_callback, NULL, NULL);
    if (FSP_SUCCESS != err) {
        printf("I2C Callback Set Error: 0x%x\n", err);
        return err;
    }

    R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MILLISECONDS);
    g_i2c1_initialized = 1;

    printf("I2C Initialized Successfully\n");
    return FSP_SUCCESS;
}

// 等待I2C事件
static uint8_t wait_for_i2c_event(i2c_master_event_t expected_event)
{
    uint32_t timeout = g_i2c1_timeout;
    g_i2c1_callback_event = I2C_MASTER_EVENT_ABORTED;

    while ((g_i2c1_callback_event != expected_event) && timeout) {
        R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_MILLISECONDS);
        timeout--;
    }

    if (timeout == 0) {
        printf("I2C Timeout! Expected: %d, Actual: %d\n",
              expected_event, g_i2c1_callback_event);
        return 0;
    }
    return 1;
}

uint8_t MAX30102_WriteReg(uint8_t reg, uint8_t value) {
    if (!g_i2c1_initialized) {
        printf("I2C not initialized\n");
        return 0;
    }

    uint8_t send_buffer[2] = {reg, value};

    // 重置事件标志
    g_i2c1_callback_event = I2C_MASTER_EVENT_ABORTED;

    // 启动写操作
    fsp_err_t err = R_IIC_MASTER_Write(&g_i2c_master1_ctrl, send_buffer, 2, false);
    if (FSP_SUCCESS != err) {
        printf("I2C Write Error: 0x%x\n", err);
        return 0;
    }

    // 等待传输完成
    if (!wait_for_i2c_event(I2C_MASTER_EVENT_TX_COMPLETE)) {
        return 0;
    }

    return 1;
}

uint8_t MAX30102_ReadReg(uint8_t reg, uint8_t *value) {
    if (!g_i2c1_initialized) {
        printf("I2C not initialized\n");
        return 0;
    }

    // 发送寄存器地址
    g_i2c1_callback_event = I2C_MASTER_EVENT_ABORTED;
    fsp_err_t err = R_IIC_MASTER_Write(&g_i2c_master1_ctrl, &reg, 1, true);
    if (FSP_SUCCESS != err) {
        printf("I2C Address Write Error: 0x%x\n", err);
        return 0;
    }

    // 等待地址发送完成
    if (!wait_for_i2c_event(I2C_MASTER_EVENT_TX_COMPLETE)) {
        return 0;
    }

    // 读取数据
    g_i2c1_callback_event = I2C_MASTER_EVENT_ABORTED;
    err = R_IIC_MASTER_Read(&g_i2c_master1_ctrl, value, 1, false);
    if (FSP_SUCCESS != err) {
        printf("I2C Read Error: 0x%x\n", err);
        return 0;
    }

    // 等待读取完成
    if (!wait_for_i2c_event(I2C_MASTER_EVENT_RX_COMPLETE)) {
        return 0;
    }

    return 1;
}

// 简单占位算法
uint16_t MAX30102_CalcHeartRate(uint32_t ir_value)
{
    return (uint16_t)(60 + (ir_value % 40));
}

uint8_t MAX30102_CalcSpO2(uint32_t ir_value, uint32_t red_value)
{
    if (red_value == 0)
        return 0;
    uint8_t spo2 = 95 + (uint8_t)((ir_value % 5));
    return spo2 > 100 ? 100 : spo2;
}

// 读取温度函数
float MAX30102_ReadTemperature(void)
{
    uint8_t temp_int, temp_frac;
    int8_t temp_signed;

    // 启动温度测量
    MAX30102_WriteReg(REG_TEMP_CONFIG, 0x01);
    R_BSP_SoftwareDelay(30, BSP_DELAY_UNITS_MILLISECONDS);

    // 读取温度值
    MAX30102_ReadReg(REG_TEMP_INTR, (uint8_t*)&temp_int);
    MAX30102_ReadReg(REG_TEMP_FRAC, &temp_frac);

    temp_signed = (int8_t)temp_int;
    return temp_signed + (temp_frac >> 4) * 0.0625f;
}

// 读取FIFO数据
uint8_t MAX30102_ReadFIFO(uint32_t *ir, uint32_t *red)
{
    uint8_t fifo_data[6];
    uint8_t reg = REG_FIFO_DATA;

    // 发送寄存器地址
    g_i2c1_callback_event = I2C_MASTER_EVENT_ABORTED;
    fsp_err_t err = R_IIC_MASTER_Write(&g_i2c_master1_ctrl, &reg, 1, true);
    if (FSP_SUCCESS != err) {
        printf("FIFO Address Write Error: 0x%x\n", err);
        return 1;
    }

    // 等待地址发送完成
    if (!wait_for_i2c_event(I2C_MASTER_EVENT_TX_COMPLETE)) {
        return 1;
    }

    // 读取数据
    g_i2c1_callback_event = I2C_MASTER_EVENT_ABORTED;
    err = R_IIC_MASTER_Read(&g_i2c_master1_ctrl, fifo_data, 6, false);
    if (FSP_SUCCESS != err) {
        printf("FIFO Read Error: 0x%x\n", err);
        return 1;
    }

    // 等待读取完成
    if (!wait_for_i2c_event(I2C_MASTER_EVENT_RX_COMPLETE)) {
        return 1;
    }

    // 解析数据 (注意数据顺序)
    *red = ((uint32_t)fifo_data[0] << 16) |
           ((uint32_t)fifo_data[1] << 8) |
           fifo_data[2];
    *ir  = ((uint32_t)fifo_data[3] << 16) |
           ((uint32_t)fifo_data[4] << 8) |
           fifo_data[5];

    // 保留18位有效数据
    *red &= 0x03FFFF;
    *ir  &= 0x03FFFF;

    return 0;
}

// 初始化 MAX30102
void MAX30102_Init(void)
{


    iic1_init();
    if (!MAX30102_WriteReg(REG_INTR_ENABLE_1, 0xC0)) { printf("init fail 1\r\n"); return; }
    if (!MAX30102_WriteReg(REG_INTR_ENABLE_2, 0x00)) { printf("init fail 2\r\n"); return; }
    if (!MAX30102_WriteReg(REG_FIFO_WR_PTR, 0x00))   { printf("init fail 3\r\n"); return; }
    if (!MAX30102_WriteReg(REG_OVF_COUNTER, 0x00))   { printf("init fail 4\r\n"); return; }
    if (!MAX30102_WriteReg(REG_FIFO_RD_PTR, 0x00))   { printf("init fail 5\r\n"); return; }
    if (!MAX30102_WriteReg(REG_FIFO_CONFIG, 0x0F))   { printf("init fail 6\r\n"); return; }
    if (!MAX30102_WriteReg(REG_MODE_CONFIG, 0x03))   { printf("init fail 7\r\n"); return; }
    if (!MAX30102_WriteReg(REG_SPO2_CONFIG, 0x27))   { printf("init fail 8\r\n"); return; }
    if (!MAX30102_WriteReg(REG_LED1_PA, 0x24))       { printf("init fail 9\r\n"); return; }
    if (!MAX30102_WriteReg(REG_LED2_PA, 0x24))       { printf("init fail 10\r\n"); return; }
    if (!MAX30102_WriteReg(REG_PILOT_PA, 0x7F))      { printf("init fail 11\r\n"); return; }
    printf("MAX30102 init ok\r\n");
}

// 复位 MAX30102
bool MAX30102_Reset(void)
{
    return MAX30102_WriteReg(REG_MODE_CONFIG, 0x40);
}

// 串口打印心率、血氧、温度
// 串口打印心率、血氧、温度（整数计算）
void MAX30102_PrintData(void)
{


    uint32_t ir, red;
    uint32_t sum_hr = 0, sum_spo2 = 0;
    int32_t sum_temp = 0; // 存储温度值乘以100后的整数
    uint16_t heart_rate;
    uint8_t spo2;
    int valid_count = 0;
    int temp_count = 0;   // 温度读取计数

    for (int i = 0; i < 100; i++)
    {
        if (MAX30102_ReadFIFO(&ir, &red) == 0)
        {
            heart_rate = MAX30102_CalcHeartRate(ir);
            spo2 = MAX30102_CalcSpO2(ir, red);

            // 每10次读取一次温度（整数计算）
            if (i % 10 == 0) {
                float temp = MAX30102_ReadTemperature();
                // 将温度转换为整数（乘以100保留两位小数）
                sum_temp += (int32_t)(temp * 100);
                temp_count++;
            }

            sum_hr += heart_rate;
            sum_spo2 += spo2;
            valid_count++;
        }
        R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MILLISECONDS);
    }

    if (valid_count > 0 && temp_count > 0)
    {
        // 计算平均值（整数运算）
         avg_hr = (sum_hr + valid_count / 2) / valid_count;         // 四舍五入
        avg_spo2 = (sum_spo2 + valid_count / 2) / valid_count;     // 四舍五入

        // 计算温度平均值（整数运算）
        int32_t avg_temp = (sum_temp + temp_count / 2) / temp_count;        // 四舍五入
        int integer_part = avg_temp / 100;      // 整数部分
        int decimal_part = abs(avg_temp % 100); // 小数部分（取绝对值）

        printf("心率: %d bpm, 血氧: %d%%, 温度: %d.%02d C\r\n",
               avg_hr, avg_spo2, integer_part, decimal_part);
        R_BSP_SoftwareDelay(2, BSP_DELAY_UNITS_SECONDS );
    }
    else
    {
        printf("MAX30102 Read Error\r\n");
        R_BSP_SoftwareDelay(2, BSP_DELAY_UNITS_SECONDS );
    }

}
