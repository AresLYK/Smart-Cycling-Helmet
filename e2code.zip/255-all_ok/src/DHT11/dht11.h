/*
 * dht11.h
 *
 *  Created on: 2025年6月8日
 *      Author: 江
 */

#ifndef DHT11_DHT11_H_
#define DHT11_DHT11_H_
#include "hal_data.h"
//#define DHT11_PIN     BSP_IO_PORT_04_PIN_00


//uint8_t DHT11_Init(void);
//uint8_t DHT11_Read_Data(uint8_t *temp,uint8_t *humi) ;
//uint8_t DHT11_Read_Byte(void);
//uint8_t DHT11_Read_Bit(void);
//uint8_t DHT11_Check(void);
//void DHT11_RST(void);
//void DHT11_IO_IN();
//void DHT11_IO_OUT();
//static inline bool DHT11_DQ_IN(void);


typedef struct {
    uint8_t humidity_int;     /* Humidity integer part */
    uint8_t humidity_dec;     /* Humidity decimal part */
    uint8_t temperature_int;  /* Temperature integer part */
    uint8_t temperature_dec;  /* Temperature decimal part */
    uint8_t checksum;         /* Checksum byte */
} dht11_data_t;

void dht11_init(void);
bool dht11_read(dht11_data_t *data);
void dht11_example(void);
void test_pin_toggle(void);
static inline float dht11_get_temperature(const dht11_data_t *data) {
    return (float)data->temperature_int + ((float)data->temperature_dec / 10.0f);
}

static inline float dht11_get_humidity(const dht11_data_t *data) {
    return (float)data->humidity_int + ((float)data->humidity_dec / 10.0f);
}



#endif /* DHT11_DHT11_H_ */
