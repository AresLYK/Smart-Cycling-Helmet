/*
 * dht11.c
 *
 *  Created on: 2025年6月8日
 *      Author: 江
 */
#include "dht11.h"


//#define DHT11_PIN     BSP_IO_PORT_04_PIN_00
//
//
//
//// 设置输入模式
//void DHT11_IO_IN()
//{
//    // 使用正确的配置选项掩码
//    ioport_cfg_options_t options = IOPORT_CFG_PORT_DIRECTION_INPUT |
//                                   IOPORT_CFG_PULLUP_ENABLE;
//
//    R_IOPORT_PinCfg(&g_ioport_ctrl, DHT11_PIN, options);
//}
//
//// 设置输出模式
//void DHT11_IO_OUT()
//{
//    // 使用开漏输出模式（推荐用于单总线设备）
//    ioport_cfg_options_t options = IOPORT_CFG_PORT_DIRECTION_OUTPUT |
//                                    IOPORT_CFG_NMOS_ENABLE |
//                                   IOPORT_CFG_PORT_OUTPUT_HIGH;
//
//    R_IOPORT_PinCfg(&g_ioport_ctrl, DHT11_PIN, options);
//}
//
//static inline bool DHT11_DQ_IN(void)
//{
//    bsp_io_level_t pin_value;  // 声明局部变量存储引脚状态
//
//    // 读取引脚状态
//    R_IOPORT_PinRead(&g_ioport_ctrl, DHT11_PIN, &pin_value);
//
//    return (pin_value == BSP_IO_LEVEL_HIGH);
//}
//
//
////检查DHT11是否存在 1不存在，0存在
//uint8_t DHT11_Check(void)
//{
//    uint8_t retry=0;
//    DHT11_IO_IN();//SET INPUT
//    while (DHT11_DQ_IN()&&retry<100)//DHT11延时40~80us
//    {
//        retry++;
//        R_BSP_SoftwareDelay(3, BSP_DELAY_UNITS_MICROSECONDS);
//    };
//    if(retry>=100)return 1;
//    else retry=0;
//    while (!DHT11_DQ_IN()&&retry<100)//DHT11延时40~80us
//    {
//        retry++;
//        R_BSP_SoftwareDelay(3, BSP_DELAY_UNITS_MICROSECONDS);
//    };
//    if(retry>=100)return 1;
//    return 0;
//}
//
//
////复位DHT11
//void DHT11_RST(void)
//{
//   DHT11_IO_OUT();         //SET OUTPUT
//   R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_00, BSP_IO_LEVEL_LOW);//设置DQ为0
//   R_BSP_SoftwareDelay(20, BSP_DELAY_UNITS_MILLISECONDS); // 延时20ms以上
//   R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_00, BSP_IO_LEVEL_HIGH);//设置DQ为1
//   R_BSP_SoftwareDelay(30, BSP_DELAY_UNITS_MICROSECONDS);
//
//}
//
//
//
//
////读取单个位数据
//uint8_t DHT11_Read_Bit(void)
//{
//    uint8_t retry=0;
//    while (DHT11_DQ_IN ()&&retry<100)//DHT11延时40~80us
//       {
//           retry++;
//           R_BSP_SoftwareDelay(3, BSP_DELAY_UNITS_MICROSECONDS);
//       }
//    retry=0;
//    R_BSP_SoftwareDelay(40, BSP_DELAY_UNITS_MICROSECONDS);
//    while (!DHT11_DQ_IN()&&retry<100)//DHT11延时40~80us
//    {
//        retry++;
//        R_BSP_SoftwareDelay(3, BSP_DELAY_UNITS_MICROSECONDS);
//    }
//    R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MICROSECONDS);
//    if(DHT11_DQ_IN())
//        return 1;
//    else
//        return 0;
//}
//
////读取字节数据值
//
//uint8_t DHT11_Read_Byte(void)
//{
//    uint8_t i,dat;
//    dat=0;
//    for (i=0;i<8;i++)
//    {
//        dat<<=1;
//        dat|=DHT11_Read_Bit();
//    }
//    return dat;
//}
//
////读取温湿度数据值
//uint8_t DHT11_Read_Data(uint8_t *temp,uint8_t *humi)
//{
//    uint8_t buf[5];
//    uint8_t i;
//    DHT11_RST();
//    if(DHT11_Check()==0)
//    {
//    for(i=0;i<5;i++)//读取40bit数据
//        {
//            buf[i]=DHT11_Read_Byte();
//        }
//    if((buf[0]+buf[1]+buf[2]+buf[3])==buf[4])
//        {
//            *humi=buf[0];
//            *temp=buf[2];
//        }
//    }else return 1;
//    return 0;
//}
//
//uint8_t DHT11_Init(void)
//{
//    DHT11_IO_IN();
//    DHT11_RST();  //复位HT11
//    return DHT11_Check();//查看DHT11的返回
//}




//#include "hal_data.h"
//#include "dht11.h"
#define DHT11_PORT BSP_IO_PORT_04
#define DHT11_PIN  BSP_IO_PORT_04_PIN_00

void dht11_init(void);
bool dht11_read(dht11_data_t *data);
static void dht11_pin_output(void);
static void dht11_pin_input(void);
static bool dht11_wait_for_level(bool level, uint32_t timeout);
// R_IOPORT_PinWrite(&g_ioport_ctrl,BSP_IO_PORT_04_PIN_00, BSP_IO_LEVEL_HIGH);
//    //延时
//    R_BSP_SoftwareDelay(1000, BSP_DELAY_UNITS_MILLISECONDS);
//    R_IOPORT_PinWrite(&g_ioport_ctrl,BSP_IO_PORT_04_PIN_00, BSP_IO_LEVEL_LOW);
//    R_IOPORT_PinCfg(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_00, IOPORT_CFG_PORT_DIRECTION_INPUT);

void test_pin_toggle(void)
{
    dht11_pin_output();
    while (1)
    {
        R_BSP_PinWrite(DHT11_PIN, BSP_IO_LEVEL_LOW);
        R_BSP_SoftwareDelay(1000, BSP_DELAY_UNITS_MILLISECONDS);
        R_BSP_PinWrite(DHT11_PIN, BSP_IO_LEVEL_HIGH);
        R_BSP_SoftwareDelay(1000, BSP_DELAY_UNITS_MILLISECONDS);
    }
}
/* Initialize DHT11 */
void dht11_init(void)
{
    dht11_pin_output();
    R_IOPORT_PinWrite(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_00, BSP_IO_LEVEL_HIGH);
    R_BSP_SoftwareDelay(1000, BSP_DELAY_UNITS_MILLISECONDS); // 上电等待1秒
}

/* Set DHT11 pin as output */
static void dht11_pin_output(void)
{
    // R_IOPORT_PinCfg(DHT11_PORT, DHT11_PIN, BSP_IO_DIRECTION_OUTPUT);
    R_IOPORT_PinCfg(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_00, IOPORT_CFG_PORT_DIRECTION_OUTPUT);
    // R_BSP_PinCfg(DHT11_PIN, BSP_IO_DIRECTION_OUTPUT);
}

/* Set DHT11 pin as input */
static void dht11_pin_input(void)
{
    // R_BSP_PinCfg(DHT11_PIN, BSP_IO_DIRECTION_INPUT);
    R_IOPORT_PinCfg(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_00, IOPORT_CFG_PORT_DIRECTION_INPUT);
}

/* Wait for pin to reach desired level with timeout */
static bool dht11_wait_for_level(bool level, uint32_t timeout)
{
    bsp_io_level_t expected_level = level ? BSP_IO_LEVEL_HIGH : BSP_IO_LEVEL_LOW;
    uint32_t count = 0;
    const uint32_t MAX_COUNT = timeout * 100;
    bsp_io_level_t pin_level;

    while (1)
    {
        R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_04_PIN_00, &pin_level);
        if (pin_level == expected_level)
            break;
        count++;
        if (count > MAX_COUNT)
            return false;
        R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_MICROSECONDS);
    }
    return true;
}

/* Read data from DHT11 sensor */
bool dht11_read(dht11_data_t *data)
{
    uint8_t i, j, temp_data[5] = {0};

    // 主机拉低18ms
    dht11_pin_output();
    R_BSP_PinWrite(DHT11_PIN, BSP_IO_LEVEL_LOW);
    R_BSP_SoftwareDelay(20, BSP_DELAY_UNITS_MILLISECONDS);

    // 主机拉高40us
    R_BSP_PinWrite(DHT11_PIN, BSP_IO_LEVEL_HIGH);
    // R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MICROSECONDS);

    // 切换为输入，准备接收DHT11响应
    dht11_pin_input();

    // 等待DHT11响应
    // if (!dht11_wait_for_level(false, 100)) return false; // DHT11拉低80us
    // if (!dht11_wait_for_level(true, 100)) return false;  // DHT11拉高80us
    // R_BSP_SoftwareDelay(10, BSP_DELAY_UNITS_MILLISECONDS);
    /* DHT11 will now send 40 bits of data */
    R_BSP_SoftwareDelay(170, BSP_DELAY_UNITS_MICROSECONDS);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 8; j++)
        {
            /* 等待50us低电平起始 */
            if (!dht11_wait_for_level(false, 80))
                return false;

            /* 等待高电平 */
            if (!dht11_wait_for_level(true, 80))
                return false;

            /* 延时30us后采样 */
            R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MICROSECONDS);
            if (R_BSP_PinRead(DHT11_PIN) == BSP_IO_LEVEL_HIGH)
                temp_data[i] |= (1 << (7 - j));

            /* 等待高电平结束 */
            if (!dht11_wait_for_level(false, 100))
                return false;
        }
    }

    /* Verify checksum */
    if (temp_data[4] != ((temp_data[0] + temp_data[1] + temp_data[2] + temp_data[3]) & 0xFF))
        return false;

    /* Copy data */
    data->humidity_int = temp_data[0];
    data->humidity_dec = temp_data[1];
    data->temperature_int = temp_data[2];
    data->temperature_dec = temp_data[3];
    data->checksum = temp_data[4];

    return true;
}

/* Example usage in your application */
void dht11_example(void)
{
    dht11_data_t sensor_data;

    /* Initialize the DHT11 sensor */
    dht11_init();

    /* Read data from sensor */
    if (dht11_read(&sensor_data))
    {
        printf("Humidity: %d.%d%%, Temperature: %d.%d°C\n",
                sensor_data.humidity_int, sensor_data.humidity_dec,
                sensor_data.temperature_int, sensor_data.temperature_dec);
    }
    else
    {
        printf("Error reading from DHT11 sensor\n");
    }
}


