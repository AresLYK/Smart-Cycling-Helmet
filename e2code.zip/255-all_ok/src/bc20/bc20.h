/*
 * bc20.h
 *
 *  Created on: 2025年6月5日
 *      Author: 江
 */

#ifndef BC20_BC20_H_
#define BC20_BC20_H_
#include "hal_data.h"
#include "stdio.h"

#define   bc20_debug  1

#if       (bc20_debug==1)
#define   bc20_debug_msg(fmt,...)   printf(fmt,##__VA_ARGS__)
#else
#define   bc20_debug_msg(fmt,...)
#endif

extern char  At_Rx_Buff[256];



void bc20_uart9_init ();
void bc20_test(void);
void Clear_Buff(void);
void bc20_uart9_callback(uart_callback_args_t*p_args);
void bc20_Send(char*cmd);
void bc20_AT(void);
void bc20_PDPACT(uint8_t time);
void bc20_UDP(void);
void bc20_Senddata(uint8_t *len,uint8_t *data);
void bc20_recdata ();
void bc20_Send(char*cmd);
void bc20_GPS();
void bc20_SenddataHEX(uint8_t *len,uint8_t *data);
//void bc20_SendData(uint8_t*data,uint16_t len);
void bc20_SendData(uint8_t* data, uint16_t len);
//void BC20_ConLWM2M(void);
//void BC20_Senddata(uint8_t *len,uint8_t *data);

#endif /* BC20_BC20_H_ */
