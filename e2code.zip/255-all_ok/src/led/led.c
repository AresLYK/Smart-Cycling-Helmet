/*
 * led.c

 *
 *  Created on: 2025年5月25日
 *      Author: 江
 */
#include "led.h"
void led_init ()
{
    R_IOPORT_Open(&g_ioport_ctrl, g_ioport.p_cfg);
}
void led_on ()
{
     R_IOPORT_PinWrite(&g_ioport_ctrl,BSP_IO_PORT_00_PIN_04 ,IOPORT_CFG_PORT_OUTPUT_HIGH);

}

void led_off ()
{
    R_IOPORT_PinWrite(&g_ioport_ctrl,BSP_IO_PORT_00_PIN_04 ,IOPORT_CFG_PORT_OUTPUT_LOW);
}

static void gpio_toggle(ioport_ctrl_t * const p_ctrl, bsp_io_port_pin_t pin)
{

    bsp_io_level_t io_level;
    R_IOPORT_PinRead(p_ctrl,pin,&io_level);
    if(io_level==BSP_IO_LEVEL_HIGH)
    {
        R_IOPORT_PinWrite(p_ctrl,pin,BSP_IO_LEVEL_LOW);
    }
    else
    {
        R_IOPORT_PinWrite(p_ctrl,pin,BSP_IO_LEVEL_HIGH);
    }
}

void led_toggl()
{
    gpio_toggle(&g_ioport_ctrl,BSP_IO_PORT_00_PIN_04);
}





