/*
 * led.h
 *
 *  Created on: 2025年5月25日
 *      Author: 江
 */

#ifndef LED_LED_H_
#define LED_LED_H_
#include "hal_data.h"
void led_init ();
void led_on ();
void led_off ();
static void gpio_toggle(ioport_ctrl_t * const p_ctrl, bsp_io_port_pin_t pin);
void led_toggl();
void init_complete();
void ledshan();

#endif /* LED_LED_H_ */
