/*
g * bc20.c
 *
 *  Created on: 2025年6月5日
 *      Author: 江
 */
#include "bc20.h"
#include "stdio.h"

/*********************************************************************************************/

/*********************************************************/
_Bool Uart9_Receive_Flag = false; // 用来判断 UART9 接收以及发送数据是否完成

_Bool Uart9_Show_Flag = false; // 控制 UART9 收发数据显示标志
_Bool Uart9_Send_Flag = false;

/* 用来接收 UART9 数据的缓冲区 */
char At_Rx_Buff[256];
uint8_t Uart9_Num;

int socketnum = 0; // 当前的socket号码
#define SERVERIP "101.200.212.234"
#define SERVERPORT 1003

void bc20_test(void)
{
    bc20_debug_msg("\r\n正在初始化bc20...\r\n");
    // bc20_uart9_init();
    bc20_debug_msg("\r\n基本AT测试...\r\n");
    bc20_AT();
    bc20_debug_msg("\r\n正在激活场景，查看IP...\r\n");
    bc20_PDPACT(200);
    // bc20_debug_msg("\r\n正在连接TCP...\r\n");
    // bc20_TCP();
}

// 初始化bc20
void bc20_uart9_init()
{

    fsp_err_t err = FSP_SUCCESS;
    err = R_SCI_UART_Open(&bc20_uart9_ctrl, &bc20_uart9_cfg);
    assert(FSP_SUCCESS == err);
}
// 清空缓冲区
void Clear_Buff(void)
{

    memset(At_Rx_Buff, 0, sizeof(At_Rx_Buff));
    Uart9_Num = 0;
}

void bc20_uart9_callback(uart_callback_args_t *p_args)
{
    switch (p_args->event)
    {
    case UART_EVENT_RX_CHAR:
    {
        At_Rx_Buff[Uart9_Num++] = (char)p_args->data;
        if (Uart9_Show_Flag)
        {
            // 将串口9的信息发送给串口4打印
            R_SCI_UART_Write(&g_uart6_ctrl, (uint8_t *)&(p_args->data), 1);
        }
        break;
    }

    case UART_EVENT_TX_COMPLETE:
    {
        Uart9_Send_Flag = true;
        break;
    }
    default:
        break;
    }
}

// 发送AT指令函数
void bc20_Send(char *cmd)
{
    R_SCI_UART_Write(&bc20_uart9_ctrl, (uint8_t *)cmd, strlen(cmd));
    Uart9_Send_Flag = false; // 发送完成标志
}

// AT测试
void bc20_AT(void)
{
    // 1。查询卡号
    bc20_Send("AT+CIMI\r\n");
    R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MILLISECONDS);
    while (!Uart9_Send_Flag)
    {
        if (strstr(At_Rx_Buff, "ERROR\r\n"))
        {
            bc20_debug_msg("检测不到卡\r\n");
            Clear_Buff();
            R_BSP_SoftwareDelay(300, BSP_DELAY_UNITS_MILLISECONDS);
        }
        Clear_Buff();
    }
    // 2.检查信号强度
    bc20_Send("AT+CESQ\r\n");
    R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MILLISECONDS);
    printf("信号质量:%s\r\n", At_Rx_Buff);
    Clear_Buff();

    // 注册网
    bc20_Send("AT+CEREG=1\r\n");
    R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_SECONDS);
    printf("IP:%s\r\n", At_Rx_Buff);
    while (!Uart9_Send_Flag)
    {
        if (strstr(At_Rx_Buff, "OK\r\n"))
        {
            bc20_debug_msg("已入网\r\n");
            Clear_Buff();
            R_BSP_SoftwareDelay(300, BSP_DELAY_UNITS_MILLISECONDS);
            break;
        }
        else if (strstr(At_Rx_Buff, "ERROR\r\n"))
        {
            bc20_debug_msg("SB\r\n");
            Clear_Buff();
            R_BSP_SoftwareDelay(300, BSP_DELAY_UNITS_MILLISECONDS);
            break;
        }
    }
}

void bc20_PDPACT(uint8_t timeout)
{
    uint8_t i;
    bc20_Send("AT+CGPADDR=1\r\n");
    R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_SECONDS);
    printf("IP:%s\r\n", At_Rx_Buff);
    Clear_Buff();
    bc20_Send("AT+CGATT?\r\n");
    R_BSP_SoftwareDelay(500, BSP_DELAY_UNITS_MILLISECONDS);
    for (i = 0; i <= timeout; i++)
    {

        if (strstr(At_Rx_Buff, "+CGATT: 1\r\n"))
        {
            bc20_debug_msg("\r\n网络已连接\r\n");
            Clear_Buff();
            break;
        }
        if (i == timeout)
        {
            bc20_debug_msg("\r\n网络连接超时\r\n");
            R_BSP_SoftwareDelay(300, BSP_DELAY_UNITS_MILLISECONDS);
            break;
        }
    }

    bc20_Send("AT+QICLOSE=0\r\n"); // 关闭旧的socket
    R_BSP_SoftwareDelay(100, BSP_DELAY_UNITS_MILLISECONDS);
    Clear_Buff();
}

void bc20_TCP(void)
{
    int errcount = 0;
    char Join[256];
    // bc20_Send("AT+CGSN=1\r\n");
    Clear_Buff();
    sprintf(Join, "AT+QIOPEN=1,%d,\"TCP\",\"%s\",%d,1234,0\r\n", socketnum, SERVERIP, SERVERPORT);
    bc20_Send(Join);
    R_BSP_SoftwareDelay(5, BSP_DELAY_UNITS_SECONDS);
    printf("COOOOO:%s\r\n", At_Rx_Buff);
    Clear_Buff();
    
}

void bc20_Senddata(uint8_t *len, uint8_t *data)
{

    char Join2[256];
    sprintf(Join2, "AT+QISEND=%d,%s,%s\r\n", socketnum, len, data);
    bc20_Send(Join2);
    R_BSP_SoftwareDelay(300, BSP_DELAY_UNITS_MILLISECONDS);
    memset(Join2, 0, 256);
    if (strstr(At_Rx_Buff, "OK\r\n"))
    {
        bc20_debug_msg("\r\n已发送\r\n");
        Clear_Buff();
        R_BSP_SoftwareDelay(300, BSP_DELAY_UNITS_MILLISECONDS);
    }
}

void bc20_recdata()
{
    char Join3[256];
    sprintf(Join3, "AT+QIRD=%d,%d\r\n", socketnum, 100);
    bc20_Send(Join3);
    R_BSP_SoftwareDelay(300, BSP_DELAY_UNITS_MILLISECONDS);
    memset(Join3, 0, 256);

    printf("COOOOO:%s\r\n", At_Rx_Buff);
    Clear_Buff();
}

// 启动GPS
void bc20_GPS()
{
    bc20_debug_msg("\r\n正在初始化bc20...\r\n");
    // bc20_uart9_init();
    bc20_debug_msg("\r\n基本AT测试...\r\n");
    bc20_AT();
    bc20_debug_msg("\r\n正在激活场景，查看IP...\r\n");
    bc20_PDPACT(200);
    bc20_Send("AT+QGNSSC=1\r\n"); // 激活GPS
    R_BSP_SoftwareDelay(2, BSP_DELAY_UNITS_SECONDS);
    Clear_Buff();
    R_BSP_SoftwareDelay(50, BSP_DELAY_UNITS_MILLISECONDS);
    bc20_Send("AT+QGNSSC?\r\n");
    R_BSP_SoftwareDelay(500, BSP_DELAY_UNITS_MILLISECONDS);
    printf("GGGGGGPS:%s\r\n", At_Rx_Buff);
    while (!Uart9_Send_Flag)
    {
        if (strstr(At_Rx_Buff, "+QGNSSC: 1\r\n"))
        {
            bc20_debug_msg("\r\nGPS启动成功\r\n");
            Clear_Buff();
            R_BSP_SoftwareDelay(300, BSP_DELAY_UNITS_MILLISECONDS);
            break;
        }
    }
    Clear_Buff();
    bc20_Send("AT+QGNSSRD=\"NMEA/RMC\"\r\n");
    // 可能延时短了
    R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_SECONDS);
    ////////////////////////
    Clear_Buff();
    ledshan(); // 初始化完成翻转LED
}

void bc20_SenddataHEX(uint8_t *len, uint8_t *data)
{

    char Join4[256];
    sprintf(Join4, "AT+QISENDEX=%d,%s,%s\r\n", socketnum, len, data);
    bc20_Send(Join4);
    R_BSP_SoftwareDelay(300, BSP_DELAY_UNITS_MILLISECONDS);
    memset(Join4, 0, 256);
    if (strstr(At_Rx_Buff, "OK\r\n"))
    {
        bc20_debug_msg("\r\nHEX格式已发送\r\n");
        Clear_Buff();
        R_BSP_SoftwareDelay(300, BSP_DELAY_UNITS_MILLISECONDS);
    }
}

void bc20_SendData(uint8_t *data, uint16_t len)
{
    while (!Uart9_Send_Flag)
    {
        // 可替换为低功耗等待：__WFI() 或任务切换
    }

    Uart9_Send_Flag = false; // 标志发送开始
    R_SCI_UART_Write(&bc20_uart9_ctrl, data, len);

    // 可选：阻塞等待发送完成（确保数据安全）
    while (!Uart9_Send_Flag)
        ;
}

// 在UART发送完成中断中调用
void uart9_tx_callback(void)
{
    Uart9_Send_Flag = true; // 必须实现此回调
}

// void _NOP(void) {
//     __asm volatile ("NOP");
// }
//
//
// void bc20_SendData(uint8_t*data,uint16_t len)
//{
//     while(!Uart9_Send_Flag)
//     {
//         _NOP();
//     }
//     Uart9_Send_Flag=false;
//     R_SCI_UART_Write(&bc20_uart9_ctrl,data,len);
// }

// void BC20_ConLWM2M(void)
//{
//
//     int errcount = 0;
//     int i=0;
//     bc20_Send("AT+MIPLCREATE\r\n");
//     if(strstr(At_Rx_Buff,"OK\r\n"))
//     {
//         bc20_debug_msg("\r\n启动LWM2M协议成功\r\n");
//         Clear_Buff();
//         R_BSP_SoftwareDelay(300, BSP_DELAY_UNITS_MILLISECONDS);
//     }
//     Clear_Buff();
//     bc20_Send("AT+MIPLADDOBJ=0,3303,1,1,1,0\r\n");//温度实例
//     R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_SECONDS);
//     Clear_Buff();
//     bc20_Send("AT+MIPLOPEN=0,86400\r\n");//打开
//     R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_SECONDS);
//     strx=strstr((const char*)At_Rx_Buff,(const char*)"+MIPLOBSERVE");//反馈观察号
//     memset(atbuf,0,256);
//     memset(objtnum,0,256);
//     while(1)
//         {
//             R_BSP_SoftwareDelay(300, BSP_DELAY_UNITS_MILLISECONDS);
//             if(strlen((const char *)At_Rx_Buff) > 0)
//             {
//                 strx=strstr((const char*)At_Rx_Buff,(const char*)"+MIPLOBSERVE");//检测到观察号结束
//                 if(strx)
//                 {
//                     sprintf(atbuf,"%s",At_Rx_Buff);
//                     strx=strstr((const char*)strx+1,(const char*)",");
//                     for(i=0;;i++)   //查询观察号
//                     {
//                         if(strx[i+1]==',')
//                             break;
//                         objtnum[i]=strx[i+1];
//                     }
//                     printf("得到AT命令:atbuf = %s \r\n",atbuf);
//                     printf("得到观察号:objtnum = %s \r\n",objtnum);
//                     break;
//                 }
//                 else    //如果没有找到目标就清空反馈的数组，找到了就跳出来
//                 {
//                     printf("连接反馈:%s\r\n",At_Rx_Buff);
//                     Clear_Buff();
//                 }
//             }
//         }
//
//         Clear_Buff();
//         printf("object number = %s\r\n",objtnum);
//         memset(atstr,0,256);
//         sprintf(atstr,"AT+MIPLOBSERVERSP=0,%s,1\r\n",objtnum);
//         bc20_Send(atstr);//发送观察命令
//         R_BSP_SoftwareDelay(300, BSP_DELAY_UNITS_MILLISECONDS);
//         strx=strstr((const char*)At_Rx_Buff,(const char*)"+MIPLDISCOVER");//返回OK
//         memset(atbuf,0,256);
//         memset(distnum,0,256);
//         while(1)
//            {
//                R_BSP_SoftwareDelay(300, BSP_DELAY_UNITS_MILLISECONDS);
//                if(strlen((const char *)At_Rx_Buff) > 0)
//                {
//                    strx=strstr((const char*)At_Rx_Buff,(const char*)"+MIPLDISCOVER");//检测到观察号结束
//                    if(strx)
//                    {
//                        sprintf(atbuf,"%s",At_Rx_Buff);
//                        strx=strstr((const char*)strx+1,(const char*)",");
//                        for(i=0;;i++)   //查询观察号
//                        {
//                            if(strx[i+1]==',')
//                                break;
//                            distnum[i]=strx[i+1];
//                        }
//                        printf("得到AT命令:atbuf = %s \r\n",atbuf);
//                        printf("得到资源号:distnum = %s \r\n",distnum);
//                        break;
//                    }
//                    else    //如果没有找到目标就清空反馈的数组，找到了就跳出来
//                    {
//                        Clear_Buff();
//                    }
//                }
//            }
//
//             Clear_Buff();
//             printf("discover number = %s\r\n",distnum);
//             memset(atstr,0,256);
//             sprintf(atstr,"AT+MIPLDISCOVERRSP=0,%s,1,4,\"5700\"\r\n",distnum);
//             bc20_Send(atstr);//发送资源命令
//             R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_SECONDS);
//             strx=strstr((const char*)At_Rx_Buff,(const char*)"OK");//返回OK
//             while(strx==NULL)
//             {
//                 errcount++;
//                 strx=strstr((const char*)At_Rx_Buff,(const char*)"OK");//返回OK
//                 if(errcount>100)     //防止死循环
//                 {
//                     errcount = 0;
//                     break;
//                 }
//             }
//             Clear_Buff();
//
// }
//
//
// int val = 100;
// void BC20_Senddata(uint8_t *len,uint8_t *data)
//{
//     int errcount=0;
//     memset(atstr,0,256);
//     sprintf(atstr,"AT+MIPLNOTIFY=0,%s,3303,0,5700,4,%s,%d,0,0\r\n",objtnum,len,val);
//     bc20_Send(atstr);//发送0 socketIP和端口后面跟对应数据长度以及数据
//     R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_SECONDS);
//     strx=strstr((const char*)At_Rx_Buff,(const char*)"OK");//返回OK
//     while(strx==NULL)
//     {
//         errcount++;
//         strx=strstr((const char*)At_Rx_Buff,(const char*)"OK");//返回OK
//         if(errcount>100)     //防止死循环
//         {
//             errcount = 0;
//             break;
//         }
//     }
//
//     Clear_Buff();
// }
