
#ifndef MPU6050_MPU6050_H_
#define MPU6050_MPU6050_H_

#include "hal_data.h"
#define MPU6050_SLAVE_ADDRESS (0x68 << 1) // MPU6050器件读地址
#define MPU6050_RA_TEMP_OUT_H 0x41        // MPU6050温度寄存器地址

#define MPU6050_WHO_AM_I 0x75
#define MPU6050_SMPLRT_DIV 0 // 8000Hz
#define MPU6050_DLPF_CFG 0
#define MPU6050_GYRO_OUT 0x43 // MPU6050陀螺仪数据寄存器地址
#define MPU6050_ACC_OUT 0x3B  // MPU6050加速度数据寄存器地址
#define MPU6050_RA_PWR_MGMT_1 0x6B
#define MPU6050_RA_SMPLRT_DIV 0x19
#define MPU6050_RA_CONFIG 0x1A
#define MPU6050_RA_GYRO_CONFIG 0x1B
#define MPU6050_RA_ACCEL_CONFIG 0x1C

extern int32_t accel[3];
void mpu6050_main(void);
uint8_t MPU6050_Init(void);
void iot_sendmpu6050(int X, int x, int Y, int y, int Z, int z);
void mpu6050_main2(void);
void mpu6050_jianche(int X, int Y, int Z, int x, int y, int z);

#endif /* MPU6050_MPU6050_H_ */
