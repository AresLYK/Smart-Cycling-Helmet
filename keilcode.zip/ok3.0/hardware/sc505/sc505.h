/*
 * sc505.h
 *
 *  Created on: 2025年6月28日
 *      Author: 江
 */

#ifndef SC505_SC505_H_
#define SC505_SC505_H_
#include "hal_data.h"
#include "../hardware/led/led.h"
void sc505_init ();

bool sc505 ();


#endif /* SC505_SC505_H_ */
