/*
 * sc505.c
 *
 *  Created on: 2025年6月28日
 *      Author: 江
 */

#include "../hardware/sc505/sc505.h"
#include "../hardware/led/led.h"

void sc505_init()
{

    R_IOPORT_Open(&g_ioport_ctrl, g_ioport.p_cfg);
}

bool sc505()
{
    bsp_io_level_t pin_state = BSP_IO_LEVEL_LOW;
    R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_05, &pin_state);

    // 添加串口调试输出
    printf("人体传感器 %s\r\n",
           (pin_state == BSP_IO_LEVEL_HIGH) ? "HIGH" : "LOW");

    if (pin_state == BSP_IO_LEVEL_HIGH)
    {
        return true; // 人体传感器检测到人体
    }
    else
    {
        // int i = 0;
        //     for(i=0;i<30;i++)
        //     {
        // beep_on();
        //     R_BSP_SoftwareDelay(100, BSP_DELAY_UNITS_MILLISECONDS); // 延时100毫秒
        //     beep_off();
        //     R_BSP_SoftwareDelay(100, BSP_DELAY_UNITS_MILLISECONDS); // 延时100毫秒
        //     }
        return false; // 没有检测到人体
    }
    // R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_SECONDS);
}
