/*
 * uart.h
 *
 *  Created on: 2025年5月27日
 *      Author: 江
 */

#ifndef UART_UART_H_
#define UART_UART_H_
#include "hal_data.h"
#include "stdio.h"

typedef struct _UART_BUF
{
    char buf [256+1];
    unsigned int index ;
}UART_BUF;


extern UART_BUF buf_uart1;


void Debug_uart6_init ();
void debug_uart_callback(uart_callback_args_t*p_args);

#endif /* UART_UART_H_ */
