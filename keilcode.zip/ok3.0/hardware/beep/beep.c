/*
   * beep.c
 *
 *  Created on: 2025年6月28日
 *      Author: 江
 */


#include "beep.h"



void beep_init ()
{
    R_IOPORT_Open(&g_ioport_ctrl, g_ioport.p_cfg);
}
void beep_on ()
{
     R_IOPORT_PinWrite(&g_ioport_ctrl,BSP_IO_PORT_01_PIN_07 ,IOPORT_CFG_PORT_OUTPUT_HIGH);

}

void beep_off ()
{
    R_IOPORT_PinWrite(&g_ioport_ctrl,BSP_IO_PORT_01_PIN_07 ,IOPORT_CFG_PORT_OUTPUT_LOW);
}
