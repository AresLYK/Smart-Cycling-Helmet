/*
 * onenet.c
 *
 *  Created on: 2025年6月14日
 *      Author: 江
 */
#include "../hardware/onenet/onenet.h"
#include "../hardware/bc20/bc20.h"

char *strx;
char atstr[256];
char atbuf[256];
char objtnum[256]; // 观察号
char distnum[256]; // 观察号

#define DEVICENAME "test"
#define PRODUCEKEY "Xy77Dbw9k3"
#define DEVICESECRET "version=2018-10-31&res=products%2FXy77Dbw9k3%2Fdevices%2Ftest&et=1918134960&method=md5&sign=wFuSvmh3twf4IjGQYpEi5w%3D%3D"

char GPRMCSTR[128];   // 转载GPS信息 GPRMC 经纬度存储的字符串
char GPRMCSTRLON[64]; // 经度存储字符串 也就是119.20694
char GPRMCSTRLAT[64]; // 维度存储字符串，也就是26.06451
char IMEINUMBER[64];  //+CGSN: "869523052178994"
//////////////////下面是纠正火星坐标的变量定义/////////////////////////
int Get_GPSdata(void);
void Getdata_Change(char status);

typedef struct
{
    char UtcDate[6];
    char longitude[11];  // 经度原数据
    char Latitude[10];   // 纬度源数据
    char longitudess[4]; // 整数部分
    char Latitudess[3];
    char longitudedd[8]; // 小数点部分
    char Latitudedd[8];
    char Truelongitude[12]; // 转换过数据
    char TrueLatitude[11];  // 转换过数据
    char getstautus;        // 获取到定位的标志状态
    float gpsdata[2];
} LongLatidata;

LongLatidata latdata;

float tempdata[2];
char latStrAF[128]; // 存放数据经纬度用来发送
char lonStrAF[128]; // 存放数据经纬度用来显示

// 平台注册
void bc20_onenet()
{
    int errcount = 0;
    bc20_Send("AT+QMTDISC=0\r\n");
    R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_SECONDS);
    Clear_Buff();

    bc20_Send("AT+QMTCLOSE=0\r\n"); // 删除句柄
    R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_SECONDS);
    Clear_Buff();

    bc20_Send("AT+QMTCFG=\"version\",0,4\r\n"); // 切换下版本
    R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_SECONDS);

    if (strstr(At_Rx_Buff, "OK\r\n"))
    {
        bc20_debug_msg("\r\n已切换\r\n");
        Clear_Buff();
        R_BSP_SoftwareDelay(300, BSP_DELAY_UNITS_MILLISECONDS);
    }
    Clear_Buff();
    
    bc20_Send("AT+QMTOPEN=0,\"mqtts.heclouds.com\",1883\r\n"); // 登录到ONENET
    R_BSP_SoftwareDelay(1, BSP_DELAY_UNITS_SECONDS);
    printf("IP:%s\r\n", At_Rx_Buff);
    strx = strstr((const char *)At_Rx_Buff, (const char *)"+QMTOPEN: 0,0"); // 返+QMTOPEN: 0,0  +QMTOPEN: 0,0
    while (strx == NULL)
    {
        errcount++;
        R_BSP_SoftwareDelay(30, BSP_DELAY_UNITS_MILLISECONDS);
        strx = strstr((const char *)At_Rx_Buff, (const char *)"+QMTOPEN: 0,0"); // 返回OK
        if (errcount > 10000)                                                   // 防止死循环
        {
            R_BSP_SoftwareDelay(300, BSP_DELAY_UNITS_MILLISECONDS);
            bc20_debug_msg("\r\n超时\r\n");
        }
    }
    Clear_Buff();

    memset(atstr, 0, 256);
    sprintf(atstr, "AT+QMTCONN=0,\"%s\",\"%s\",\"%s\"\r\n", DEVICENAME, PRODUCEKEY, DEVICESECRET); //+QMTCONN: 0,0,0
    bc20_Send(atstr);                                                                              // 发送链接到onenet
    R_BSP_SoftwareDelay(2, BSP_DELAY_UNITS_SECONDS);
    printf("IP:%s\r\n", At_Rx_Buff);
    if (strstr(At_Rx_Buff, "+QMTCONN: 0,0,0\r\n"))
    {
        bc20_debug_msg("\r\n链接到onenet\r\n");
        Clear_Buff();
        R_BSP_SoftwareDelay(300, BSP_DELAY_UNITS_MILLISECONDS);
    }
}

void iot_send(int x, int y)
{
    char at_cmd[256];
    sprintf(at_cmd, "AT+QMTPUB=0,0,0,0,\"$sys/Xy77Dbw9k3/test/dp/post/json\",{\"id\":123,\"dp\":{\"Temp\":[{\"v\":%d}],\"Humi\":[{\"v\":%d}]}}\r\n",
            x, y);
    bc20_Send(at_cmd);
    printf("IP:%s\r\n", at_cmd);
    memset(at_cmd, 0, 256);
}

char *Get_GPS_RMC(char type)
{
    Clear_Buff();
    memset(GPRMCSTR, 0, 128);

    bc20_Send("AT+QGNSSRD=\"NMEA/RMC\"\r\n"); // 查询激活状态
    R_BSP_SoftwareDelay(300, BSP_DELAY_UNITS_MILLISECONDS);
    strx = strstr((const char *)At_Rx_Buff, (const char *)"$GNRMC"); // 返1

    while (strx == NULL)
    {
        Clear_Buff();
        bc20_Send("AT+QGNSSRD=\"NMEA/RMC\"\r\n"); // 获取激活状态
        R_BSP_SoftwareDelay(300, BSP_DELAY_UNITS_MILLISECONDS);
        strx = strstr((const char *)At_Rx_Buff, (const char *)"$GNRMC"); // 返回1,表明注网成功
    }
    sprintf(GPRMCSTR, "%s", strx);

    Clear_Buff(); // 打印收到的GPS信息
    GPRMCSTR[2] = 'P';

    // printf("============GETGPRMC==============\r\n%s", GPRMCSTR); // 打印GPRMC

    memset(latStrAF, 0, 128);
    memset(lonStrAF, 0, 128);

    Get_GPSdata();

    if (type == 1)
        return latStrAF;
    if (type == 2)
        return lonStrAF;

    return 0;
}

// 解GPS析函数
//  $GNRMC,091900.00,A,2603.9680,N,11912.4174,E,0.189,,201022,,,A,V*1A
int Get_GPSdata()
{
    int i = 0;
    strx = strstr((const char *)GPRMCSTR, (const char *)"A,"); // 获取纬度的位置
    if (strx)
    {
        for (i = 0; i < 9; i++)
        {
            latdata.Latitude[i] = strx[i + 2]; // 获取纬度值2603.9576
        }
        strx = strstr((const char *)GPRMCSTR, (const char *)"N,"); // 获取经度值
        if (strx)
        {
            for (i = 0; i < 10; i++) // 获取经度 11912.4098
            {
                latdata.longitude[i] = strx[i + 2];
            }
        }

        printf("latdata.Latitude ,%s \r\n", latdata.Latitude);
        printf("latdata.longitude ,%s \r\n", latdata.longitude);
        latdata.getstautus = 1;
    }

    else
    {

        latdata.getstautus = 0;
    }
    // Getdata_Change(latdata.getstautus);//数据换算
    ConvertAndPublish();
    Clear_Buff();
    return 0;
}

void Getdata_Change(char status)
{
    if (status)
    {
        // 确保原始数据格式正确
        printf("Raw Longitude: %s\n", latdata.longitude);
        printf("Raw Latitude: %s\n", latdata.Latitude);

        // 1. 经度转换（安全版）
        double longitude = 0.0;
        if (strlen(latdata.longitude) >= 9)
        {
            // 安全提取各部分
            char lon_deg_part[4] = {0};
            char lon_min_int_part[3] = {0};
            char lon_min_frac_part[5] = {0};

            // 安全复制（使用memcpy避免截断警告）
            memcpy(lon_deg_part, latdata.longitude, 3);
            memcpy(lon_min_int_part, latdata.longitude + 3, 2);
            memcpy(lon_min_frac_part, latdata.longitude + 6, 4);

            // 转换为数值
            double lon_deg = atoi(lon_deg_part);
            double lon_min = atoi(lon_min_int_part) + atof(lon_min_frac_part) / 10000.0;

            // 计算十进制经度
            longitude = lon_deg + lon_min / 60.0;
        }

        // 2. 纬度转换（安全版）
        double latitude = 0.0;
        if (strlen(latdata.Latitude) >= 8)
        {
            // 安全提取各部分
            char lat_deg_part[3] = {0};
            char lat_min_int_part[3] = {0};
            char lat_min_frac_part[5] = {0};

            // 安全复制
            memcpy(lat_deg_part, latdata.Latitude, 2);
            memcpy(lat_min_int_part, latdata.Latitude + 2, 2);
            memcpy(lat_min_frac_part, latdata.Latitude + 5, 4);

            // 转换为数值
            double lat_deg = atoi(lat_deg_part);
            double lat_min = atoi(lat_min_int_part) + atof(lat_min_frac_part) / 10000.0;

            // 计算十进制纬度
            latitude = lat_deg + lat_min / 60.0;
        }

        // 3. 安全格式化字符串
        snprintf(lonStrAF, sizeof(lonStrAF), "%.6f", longitude);
        snprintf(latStrAF, sizeof(latStrAF), "%.6f", latitude);

        // 4. 移除尾部多余的零
        trimTrailingZeros(lonStrAF);
        trimTrailingZeros(latStrAF);

        printf("Converted Longitude: %s\n", lonStrAF);
        printf("Converted Latitude: %s\n", latStrAF);
    }
    else
    {
        latdata.gpsdata[0] = 0;
        latdata.gpsdata[1] = 0;
        memset(lonStrAF, 0, sizeof(lonStrAF));
        memset(latStrAF, 0, sizeof(latStrAF));
    }
}

// 优化的尾部零移除函数
void trimTrailingZeros(char *str)
{
    char *decimal_point = strchr(str, '.');
    if (decimal_point)
    {
        char *end = str + strlen(str) - 1;
        while (end > decimal_point && *end == '0')
        {
            *end-- = '\0';
        }
        if (end == decimal_point)
        {
            *decimal_point = '\0'; // 移除多余的小数点
        }
    }
}

void ConvertAndPublish()
{

    // 确保原始数据有效
    if (latdata.getstautus != 1)
    {
        printf("Invalid GPS status\n");
        memset(latStrAF, 0, sizeof(latStrAF));
        memset(lonStrAF, 0, sizeof(lonStrAF));
        return;
    }

    printf("Raw Latitude: %s\n", latdata.Latitude);
    printf("Raw Longitude: %s\n", latdata.longitude);

    // 检查原始数据长度
    if (strlen(latdata.Latitude) < 9 || strlen(latdata.longitude) < 10)
    {
        printf("Invalid GPS data length\n");
        memset(latStrAF, 0, sizeof(latStrAF));
        memset(lonStrAF, 0, sizeof(lonStrAF));
        return;
    }

    // 纬度转换：2749.2117 -> 27 + (492117/600000)
    char lat_deg_str[3] = {0};
    char lat_min_str[8] = {0};
    strncpy(lat_deg_str, latdata.Latitude, 2);
    strncpy(lat_min_str, latdata.Latitude + 2, 7);
    lat_min_str[7] = '\0';

    // 解析分部分（移除小数点）
    uint32_t lat_min_total = 0;
    int lat_digit_count = 0;
    for (int i = 0; i < strlen(lat_min_str); i++)
    {
        if (lat_min_str[i] >= '0' && lat_min_str[i] <= '9')
        {
            lat_min_total = lat_min_total * 10 + (lat_min_str[i] - '0');
            lat_digit_count++;
        }
    }

    // 补足6位小数
    while (lat_digit_count < 7)
    { // 2位整数 + 6位小数 = 7位
        lat_min_total *= 10;
        lat_digit_count++;
    }

    uint32_t lat_deg = atoi(lat_deg_str);
    // 计算：度 + (分/60) 的百万分之一度表示（带四舍五入）
    uint32_t lat_value = lat_deg * 1000000 + (lat_min_total + 300) / 6; // 四舍五入

    // 经度转换：11306.4590 -> 113 + (64621/600000)
    char lon_deg_str[4] = {0};
    char lon_min_str[8] = {0};
    strncpy(lon_deg_str, latdata.longitude, 3);
    strncpy(lon_min_str, latdata.longitude + 3, 7);
    lon_min_str[7] = '\0';

    uint32_t lon_min_total = 0;
    int lon_digit_count = 0;
    for (int i = 0; i < strlen(lon_min_str); i++)
    {
        if (lon_min_str[i] >= '0' && lon_min_str[i] <= '9')
        {
            lon_min_total = lon_min_total * 10 + (lon_min_str[i] - '0');
            lon_digit_count++;
        }
    }

    // 补足6位小数
    while (lon_digit_count < 7)
    { // 2位整数 + 6位小数 = 7位
        lon_min_total *= 10;
        lon_digit_count++;
    }

    uint32_t lon_deg = atoi(lon_deg_str);
    uint32_t lon_value = lon_deg * 1000000 + (lon_min_total + 300) / 6; // 四舍五入

    // 修复格式字符串 - 使用 %u 替代 %llu
    snprintf(latStrAF, sizeof(latStrAF), "%u.%06u",
             lat_value / 1000000,
             lat_value % 1000000);

    snprintf(lonStrAF, sizeof(lonStrAF), "%u.%06u",
             lon_value / 1000000,
             lon_value % 1000000);

    // 移除尾部多余的零（可选）
    for (char *p = latStrAF + strlen(latStrAF) - 1; p > strchr(latStrAF, '.'); p--)
    {
        if (*p == '0')
            *p = '\0';
        else
            break;
        if (*(p - 1) == '.')
        {
            *(p - 1) = '\0';
            break;
        }
    }

    for (char *p = lonStrAF + strlen(lonStrAF) - 1; p > strchr(lonStrAF, '.'); p--)
    {
        if (*p == '0')
            *p = '\0';
        else
            break;
        if (*(p - 1) == '.')
        {
            *(p - 1) = '\0';
            break;
        }
    }

    printf("Converted Latitude: %s\n", latStrAF);
    printf("Converted Longitude: %s\n", lonStrAF);
}

void iot_sendGPS(char *x, char *y)
{
    char at_cmd[256];
    sprintf(at_cmd, "AT+QMTPUB=0,0,0,0,\"$sys/Xy77Dbw9k3/test/dp/post/json\",{\"id\":123,\"dp\":{\"location\":[{\"v\":{\"lon\":%s,\"lat\":%s}}]}}\r\n",
            x, y);
    bc20_Send(at_cmd);
    printf("IP:%s\r\n", at_cmd);
    memset(at_cmd, 0, 256);
}

void iot_sendMAX30102(int x, int y)
{
    char at_cmd[256];
    sprintf(at_cmd, "AT+QMTPUB=0,0,0,0,\"$sys/Xy77Dbw9k3/test/dp/post/json\",{\"id\":123,\"dp\":{\"XinLv\":[{\"v\":%d}],\"XueYang\":[{\"v\":%d}]}}\r\n",
            x, y);
    bc20_Send(at_cmd);
    printf("IP:%s\r\n", at_cmd);
    memset(at_cmd, 0, 256);
}
