/*
 * systick.c
 *
 *  Created on: 2025年5月26日
 *      Author: 江
 */
#include "systick.h"

static __IO uint32_t IT_nums;//延时需触发的次数
static uint32_t IT_period;

void systick_init (uint32_t IT_frequency )
{
    IT_period=SystemCoreClock / IT_frequency;
    uint32_t err=SysTick_Config( IT_period);
    assert(err==0);
}


void systick_delay (uint32_t delay,sys_delay_units_t uint)
{
    uint32_t SumTime=delay * uint;//总延时时间
    IT_nums=SumTime/IT_period;
    SysTick-> VAL=0UL;//计数清零
    while(IT_nums!=0);

}

extern void SysTick_Handler (void);

void SysTick_Handler(void)
{
    if (IT_nums!=0x00)
    {
        IT_nums--;

    }
}
