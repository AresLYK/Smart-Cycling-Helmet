#include "yuying.h"
void yuying_init()
{

    R_IOPORT_Open(&g_ioport_ctrl, g_ioport.p_cfg);
}

void yuying()
{
    // LED
    bsp_io_level_t pin_state = BSP_IO_LEVEL_LOW;
    R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_02_PIN_09, &pin_state);

    // 添加串口调试输出
    printf("LED State: %s\r\n",
           (pin_state == BSP_IO_LEVEL_HIGH) ? "HIGH" : "LOW");

    if (pin_state == BSP_IO_LEVEL_HIGH)
    {
        led_on();
        // led_off();
    }
    else
    {
        led_off();
        // led_on();
    }
    // R_BSP_SoftwareDelay(200, BSP_DELAY_UNITS_MILLISECONDS);
}

void yuying2()
{

    // 蜂鸣器
    bsp_io_level_t pin_state2 = BSP_IO_LEVEL_LOW;
    R_IOPORT_PinRead(&g_ioport_ctrl, BSP_IO_PORT_01_PIN_13, &pin_state2);

    // 添加串口调试输出
    printf("BEEP State: %s\r\n",
           (pin_state2 == BSP_IO_LEVEL_HIGH) ? "HIGH" : "LOW");

    if (pin_state2 == BSP_IO_LEVEL_HIGH)
    {
        beep_on();
    }
    else if (pin_state2 == BSP_IO_LEVEL_LOW)
    {
        beep_off();
    }
}
