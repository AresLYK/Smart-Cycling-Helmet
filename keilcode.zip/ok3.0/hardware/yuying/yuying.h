/*
 * yuying.h
 *
 *  Created on: 2025年7月4日
 *      Author: 江
 */

#ifndef YUYING_YUYING_H_
#define YUYING_YUYING_H_

#include "hal_data.h"
#include "../hardware/beep/beep.h"
#include "../hardware/led/led.h"
void yuying_init ();
void yuying ();
 void yuying2 () ;
#endif /* YUYING_YUYING_H_ */
